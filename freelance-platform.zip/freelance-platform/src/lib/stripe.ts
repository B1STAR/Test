import { loadStripe } from '@stripe/stripe-js'
import Stripe from 'stripe'

// Client-side Stripe
export const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

// Server-side Stripe
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20'
})

// Types pour les paiements
export interface PaymentIntentData {
  amount: number // en centimes
  currency: string
  metadata: {
    job_id?: string
    milestone_id?: string
    freelancer_id: string
    client_id: string
    platform_fee: string
  }
}

// Créer un PaymentIntent pour un paiement
export async function createPaymentIntent(data: PaymentIntentData) {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: data.amount,
      currency: data.currency,
      metadata: data.metadata,
      automatic_payment_methods: {
        enabled: true
      }
    })

    return { paymentIntent, error: null }
  } catch (error) {
    console.error('Erreur lors de la création du PaymentIntent:', error)
    return { paymentIntent: null, error }
  }
}

// Confirmer un paiement
export async function confirmPayment(paymentIntentId: string) {
  try {
    const paymentIntent = await stripe.paymentIntents.confirm(paymentIntentId)
    return { paymentIntent, error: null }
  } catch (error) {
    console.error('Erreur lors de la confirmation du paiement:', error)
    return { paymentIntent: null, error }
  }
}

// Créer un compte Stripe Connect pour un freelance
export async function createConnectAccount(freelancerId: string, email: string) {
  try {
    const account = await stripe.accounts.create({
      type: 'express',
      email,
      metadata: {
        freelancer_id: freelancerId
      }
    })

    return { account, error: null }
  } catch (error) {
    console.error('Erreur lors de la création du compte Connect:', error)
    return { account: null, error }
  }
}

// Créer un lien d'onboarding pour Stripe Connect
export async function createAccountLink(accountId: string) {
  try {
    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard/freelancer/stripe/refresh`,
      return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard/freelancer/stripe/success`,
      type: 'account_onboarding'
    })

    return { accountLink, error: null }
  } catch (error) {
    console.error('Erreur lors de la création du lien d\'onboarding:', error)
    return { accountLink: null, error }
  }
}

// Effectuer un transfert vers un freelance
export async function transferToFreelancer(
  amount: number,
  stripeAccountId: string,
  metadata: any
) {
  try {
    const transfer = await stripe.transfers.create({
      amount,
      currency: 'eur',
      destination: stripeAccountId,
      metadata
    })

    return { transfer, error: null }
  } catch (error) {
    console.error('Erreur lors du transfert:', error)
    return { transfer: null, error }
  }
}

// Récupérer les détails d'un compte Connect
export async function getConnectAccount(accountId: string) {
  try {
    const account = await stripe.accounts.retrieve(accountId)
    return { account, error: null }
  } catch (error) {
    console.error('Erreur lors de la récupération du compte:', error)
    return { account: null, error }
  }
}

// Calculer les frais de plateforme
export function calculatePlatformFee(amount: number, feePercentage: number = 10): number {
  return Math.round(amount * (feePercentage / 100))
}

// Formater les montants pour l'affichage
export function formatAmount(amount: number, currency: string = 'EUR'): string {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: currency.toUpperCase(),
    minimumFractionDigits: 2
  }).format(amount / 100) // Stripe utilise les centimes
}

// Créer une intention de paiement pour escrow
export async function createEscrowPayment(
  jobId: number,
  clientId: string,
  freelancerId: string,
  amount: number,
  platformFeePercentage: number = 10
) {
  const platformFee = calculatePlatformFee(amount, platformFeePercentage)
  const totalAmount = amount + platformFee

  return createPaymentIntent({
    amount: totalAmount,
    currency: 'eur',
    metadata: {
      job_id: jobId.toString(),
      freelancer_id: freelancerId,
      client_id: clientId,
      platform_fee: platformFee.toString()
    }
  })
}

// Libérer les fonds de l'escrow vers le freelance
export async function releaseEscrowPayment(
  paymentIntentId: string,
  freelancerStripeAccountId: string,
  amount: number,
  platformFee: number
) {
  try {
    // Récupérer le PaymentIntent
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)
    
    if (paymentIntent.status !== 'succeeded') {
      throw new Error('Le paiement n\'a pas été confirmé')
    }

    // Transférer les fonds vers le freelance (montant moins les frais de plateforme)
    const freelancerAmount = amount - platformFee
    
    const transfer = await transferToFreelancer(
      freelancerAmount,
      freelancerStripeAccountId,
      {
        payment_intent_id: paymentIntentId,
        type: 'escrow_release'
      }
    )

    return { transfer, error: null }
  } catch (error) {
    console.error('Erreur lors de la libération de l\'escrow:', error)
    return { transfer: null, error }
  }
}
