import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types pour la base de données
export interface User {
  id: string
  email: string
  role: 'client' | 'freelancer' | 'admin'
  first_name: string
  last_name: string
  avatar_url?: string
  phone?: string
  location?: string
  created_at: string
  updated_at: string
  is_verified: boolean
}

export interface FreelancerProfile {
  user_id: string
  title?: string
  overview?: string
  hourly_rate?: number
  availability?: string
  country?: string
}

export interface Skill {
  id: number
  name: string
}

export interface Job {
  id: number
  client_id: string
  title: string
  description: string
  budget_type: 'fixed' | 'hourly'
  budget_amount?: number
  status: 'open' | 'in_progress' | 'completed' | 'cancelled'
  created_at: string
  updated_at: string
}

export interface Proposal {
  id: number
  job_id: number
  freelancer_id: string
  cover_letter: string
  proposed_rate: number
  status: 'submitted' | 'accepted' | 'rejected'
  created_at: string
}

export interface WorkRoom {
  id: number
  job_id: number
  freelancer_id: string
  status: 'active' | 'completed' | 'disputed'
  created_at: string
}

export interface Message {
  id: number
  workroom_id: number
  sender_id: string
  content: string
  created_at: string
}

export interface Transaction {
  id: number
  job_id: number
  amount: number
  commission_amount: number
  status: 'pending' | 'completed' | 'failed'
  payment_method: 'stripe' | 'paypal'
  created_at: string
}
