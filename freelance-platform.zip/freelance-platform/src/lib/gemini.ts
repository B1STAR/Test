import { GoogleGenerativeAI } from '@google/generative-ai'

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!)

export const geminiModel = genAI.getGenerativeModel({ model: 'gemini-pro' })

// Fonction pour le matching intelligent entre freelances et jobs
export async function generateJobFreelancerMatch(
  jobDescription: string,
  jobSkills: string[],
  freelancerProfile: {
    title: string
    overview: string
    skills: string[]
    experience: string
  }
): Promise<{ matchScore: number; matchReason: string }> {
  const prompt = `
    Analyse cette offre d'emploi et ce profil freelance pour déterminer le niveau de compatibilité.

    OFFRE D'EMPLOI:
    Description: ${jobDescription}
    Compétences requises: ${jobSkills.join(', ')}

    PROFIL FREELANCE:
    Titre: ${freelancerProfile.title}
    Description: ${freelancerProfile.overview}
    Compétences: ${freelancerProfile.skills.join(', ')}
    Expérience: ${freelancerProfile.experience}

    Évalue la compatibilité sur une échelle de 0 à 100 et fournis une explication concise.
    Réponds uniquement au format JSON:
    {
      "matchScore": [score de 0 à 100],
      "matchReason": "[explication en français de 1-2 phrases]"
    }
  `

  try {
    const result = await geminiModel.generateContent(prompt)
    const response = await result.response
    const text = response.text()
    
    // Parse la réponse JSON
    const match = JSON.parse(text)
    return {
      matchScore: Math.min(100, Math.max(0, match.matchScore)),
      matchReason: match.matchReason
    }
  } catch (error) {
    console.error('Erreur lors du matching IA:', error)
    // Fallback: calcul basique basé sur les compétences communes
    const commonSkills = jobSkills.filter(skill => 
      freelancerProfile.skills.some(fSkill => 
        fSkill.toLowerCase().includes(skill.toLowerCase()) ||
        skill.toLowerCase().includes(fSkill.toLowerCase())
      )
    )
    const matchScore = Math.round((commonSkills.length / jobSkills.length) * 100)
    
    return {
      matchScore,
      matchReason: `${commonSkills.length} compétences communes sur ${jobSkills.length} requises.`
    }
  }
}

// Fonction pour améliorer la description d'un job
export async function enhanceJobDescription(description: string): Promise<string> {
  const prompt = `
    Améliore cette description de projet freelance pour la rendre plus claire, professionnelle et attractive pour les freelances.
    
    Description originale: ${description}
    
    Règles:
    - Garde le même contenu de base
    - Améliore la structure et la clarté
    - Rends le texte plus engageant
    - Utilise un ton professionnel mais accessible
    - Garde la même longueur approximative
    - Réponds uniquement avec la description améliorée, sans commentaires
  `

  try {
    const result = await geminiModel.generateContent(prompt)
    const response = await result.response
    return response.text().trim()
  } catch (error) {
    console.error('Erreur lors de l\'amélioration de la description:', error)
    return description // Retourne la description originale en cas d'erreur
  }
}

// Fonction pour suggérer des compétences basées sur une description
export async function suggestSkillsFromDescription(description: string): Promise<string[]> {
  const prompt = `
    Analyse cette description de projet et suggère les compétences techniques les plus pertinentes.
    
    Description: ${description}
    
    Règles:
    - Suggère 5-10 compétences maximum
    - Privilégie les compétences techniques spécifiques
    - Utilise les noms standards (ex: "React", "Node.js", "PHP", "Python")
    - Réponds uniquement avec une liste JSON de chaînes de caractères
    - Exemple: ["React", "Node.js", "TypeScript", "MongoDB"]
  `

  try {
    const result = await geminiModel.generateContent(prompt)
    const response = await result.response
    const text = response.text()
    
    // Parse la réponse JSON
    const skills = JSON.parse(text)
    return Array.isArray(skills) ? skills : []
  } catch (error) {
    console.error('Erreur lors de la suggestion de compétences:', error)
    return [] // Retourne un tableau vide en cas d'erreur
  }
}

// Fonction pour générer des suggestions de profil freelance
export async function generateProfileSuggestions(
  currentProfile: {
    title?: string
    overview?: string
    skills: string[]
  }
): Promise<{
  titleSuggestions: string[]
  overviewSuggestions: string
  skillSuggestions: string[]
}> {
  const prompt = `
    Analyse ce profil freelance et suggère des améliorations.
    
    Profil actuel:
    Titre: ${currentProfile.title || 'Non renseigné'}
    Description: ${currentProfile.overview || 'Non renseignée'}
    Compétences: ${currentProfile.skills.join(', ')}
    
    Suggère:
    1. 3 titres professionnels alternatifs (plus accrocheurs)
    2. Une description améliorée (2-3 phrases, professionnelle et engageante)
    3. 3-5 compétences complémentaires pertinentes
    
    Réponds au format JSON:
    {
      "titleSuggestions": ["titre1", "titre2", "titre3"],
      "overviewSuggestions": "description améliorée",
      "skillSuggestions": ["compétence1", "compétence2", "compétence3"]
    }
  `

  try {
    const result = await geminiModel.generateContent(prompt)
    const response = await result.response
    const text = response.text()
    
    const suggestions = JSON.parse(text)
    return {
      titleSuggestions: suggestions.titleSuggestions || [],
      overviewSuggestions: suggestions.overviewSuggestions || '',
      skillSuggestions: suggestions.skillSuggestions || []
    }
  } catch (error) {
    console.error('Erreur lors de la génération de suggestions:', error)
    return {
      titleSuggestions: [],
      overviewSuggestions: '',
      skillSuggestions: []
    }
  }
}
