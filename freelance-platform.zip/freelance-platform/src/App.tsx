import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { ThemeProvider } from './components/ThemeProvider'
import { AuthProvider } from './components/AuthProvider'
import { useAuth } from './hooks/useAuth'
import { Toaster } from './components/ui/toaster'

// Layout components
import Header from './components/layout/Header'
import Footer from './components/layout/Footer'

// Pages
import HomePage from './pages/HomePage'
import LoginPage from './pages/auth/LoginPage'
import RegisterPage from './pages/auth/RegisterPage'
import DashboardPage from './pages/dashboard/DashboardPage'
import FreelancerDashboard from './pages/dashboard/FreelancerDashboard'
import ClientDashboard from './pages/dashboard/ClientDashboard'
import AdminDashboard from './pages/dashboard/AdminDashboard'
import JobsPage from './pages/jobs/JobsPage'
import JobDetailsPage from './pages/jobs/JobDetailsPage'
import PostJobPage from './pages/jobs/PostJobPage'
import ProfilePage from './pages/profile/ProfilePage'
import WorkroomPage from './pages/workroom/WorkroomPage'
import PaymentPage from './pages/payment/PaymentPage'
import AffiliatePage from './pages/affiliate/AffiliatePage'

// Protected Route component
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  return <>{children}</>
}

// Main App component
function AppContent() {
  const { userProfile } = useAuth()

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="min-h-screen">
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/jobs" element={<JobsPage />} />
          <Route path="/jobs/:id" element={<JobDetailsPage />} />

          {/* Protected routes */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/freelancer"
            element={
              <ProtectedRoute>
                <FreelancerDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/client"
            element={
              <ProtectedRoute>
                <ClientDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/admin"
            element={
              <ProtectedRoute>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/post-job"
            element={
              <ProtectedRoute>
                <PostJobPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <ProfilePage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/workroom/:id"
            element={
              <ProtectedRoute>
                <WorkroomPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/payment/:id"
            element={
              <ProtectedRoute>
                <PaymentPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/affiliate"
            element={
              <ProtectedRoute>
                <AffiliatePage />
              </ProtectedRoute>
            }
          />

          {/* Redirect based on user role */}
          <Route
            path="/dashboard-redirect"
            element={
              <ProtectedRoute>
                <Navigate
                  to={
                    userProfile?.role === 'admin'
                      ? '/dashboard/admin'
                      : userProfile?.role === 'freelancer'
                      ? '/dashboard/freelancer'
                      : '/dashboard/client'
                  }
                  replace
                />
              </ProtectedRoute>
            }
          />
        </Routes>
      </main>
      <Footer />
      <Toaster />
    </div>
  )
}

function App() {
  return (
    <ThemeProvider defaultTheme="light">
      <AuthProvider>
        <Router>
          <AppContent />
        </Router>
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App
