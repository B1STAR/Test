import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'
import { Button } from '../ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import { 
  User, 
  Settings, 
  LogOut, 
  PlusCircle, 
  Search,
  Menu,
  X
} from 'lucide-react'
import { useState } from 'react'

export default function Header() {
  const { user, userProfile, signOut } = useAuth()
  const navigate = useNavigate()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const handleSignOut = async () => {
    await signOut()
    navigate('/')
  }

  const getDashboardLink = () => {
    if (!userProfile) return '/dashboard'
    switch (userProfile.role) {
      case 'admin':
        return '/dashboard/admin'
      case 'freelancer':
        return '/dashboard/freelancer'
      case 'client':
        return '/dashboard/client'
      default:
        return '/dashboard'
    }
  }

  return (
    <header className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">FL</span>
              </div>
              <span className="font-bold text-xl text-gray-900">FreelancePro</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/jobs" className="text-gray-700 hover:text-blue-600 transition-colors">
              Missions
            </Link>
            <Link to="/freelancers" className="text-gray-700 hover:text-blue-600 transition-colors">
              Freelances
            </Link>
            <Link to="/about" className="text-gray-700 hover:text-blue-600 transition-colors">
              À propos
            </Link>
          </nav>

          {/* Right side - Auth/User menu */}
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                {/* Post Job Button (for clients) */}
                {userProfile?.role === 'client' && (
                  <Button asChild className="hidden sm:flex">
                    <Link to="/post-job">
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Publier une mission
                    </Link>
                  </Button>
                )}

                {/* User Menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage 
                          src={userProfile?.avatar_url || '/images/default-avatar.jpg'} 
                          alt={`${userProfile?.first_name} ${userProfile?.last_name}`} 
                        />
                        <AvatarFallback>
                          {userProfile?.first_name?.[0]}{userProfile?.last_name?.[0]}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <div className="flex items-center justify-start gap-2 p-2">
                      <div className="flex flex-col space-y-1 leading-none">
                        <p className="font-medium">{userProfile?.first_name} {userProfile?.last_name}</p>
                        <p className="w-[200px] truncate text-sm text-muted-foreground">
                          {user.email}
                        </p>
                      </div>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to={getDashboardLink()}>
                        <Settings className="mr-2 h-4 w-4" />
                        Tableau de bord
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/profile">
                        <User className="mr-2 h-4 w-4" />
                        Profil
                      </Link>
                    </DropdownMenuItem>
                    {userProfile?.role === 'freelancer' && (
                      <DropdownMenuItem asChild>
                        <Link to="/dashboard/freelancer">
                          <Search className="mr-2 h-4 w-4" />
                          Missions disponibles
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleSignOut}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Déconnexion
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="hidden md:flex items-center space-x-4">
                <Button variant="ghost" asChild>
                  <Link to="/login">Connexion</Link>
                </Button>
                <Button asChild>
                  <Link to="/register">Inscription</Link>
                </Button>
              </div>
            )}

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t bg-white py-4">
            <nav className="flex flex-col space-y-4">
              <Link 
                to="/jobs" 
                className="text-gray-700 hover:text-blue-600 transition-colors px-4"
                onClick={() => setMobileMenuOpen(false)}
              >
                Missions
              </Link>
              <Link 
                to="/freelancers" 
                className="text-gray-700 hover:text-blue-600 transition-colors px-4"
                onClick={() => setMobileMenuOpen(false)}
              >
                Freelances
              </Link>
              <Link 
                to="/about" 
                className="text-gray-700 hover:text-blue-600 transition-colors px-4"
                onClick={() => setMobileMenuOpen(false)}
              >
                À propos
              </Link>
              
              {!user && (
                <div className="flex flex-col space-y-2 px-4 pt-4 border-t">
                  <Button variant="ghost" asChild className="justify-start">
                    <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                      Connexion
                    </Link>
                  </Button>
                  <Button asChild className="justify-start">
                    <Link to="/register" onClick={() => setMobileMenuOpen(false)}>
                      Inscription
                    </Link>
                  </Button>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
