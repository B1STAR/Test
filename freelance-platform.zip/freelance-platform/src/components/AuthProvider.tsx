import React, { createContext, useContext } from 'react'
import { useAuth } from '../hooks/useAuth'
import { User } from '@supabase/supabase-js'
import { User as CustomUser } from '../lib/supabase'

interface AuthContextType {
  user: User | null
  userProfile: CustomUser | null
  loading: boolean
  signUp: (email: string, password: string, userData: {
    first_name: string
    last_name: string
    role: 'client' | 'freelancer'
  }) => Promise<{ data: any; error: any }>
  signIn: (email: string, password: string) => Promise<{ data: any; error: any }>
  signOut: () => Promise<{ error: any }>
  updateProfile: (updates: Partial<CustomUser>) => Promise<{ data: any; error: any }>
  resetPassword: (email: string) => Promise<{ error: any }>
  fetchUserProfile: (userId: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const auth = useAuth()

  return (
    <AuthContext.Provider value={auth}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuthContext() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuthContext must be used within an AuthProvider')
  }
  return context
}
