import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { Progress } from '../../components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { 
  MessageSquare, 
  FileText, 
  Calendar, 
  DollarSign,
  Upload,
  Download,
  Users,
  Clock
} from 'lucide-react'

export default function WorkroomPage() {
  const { id } = useParams()
  const [progress] = useState(65)

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            WorkRoom - Développement site e-commerce
          </h1>
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <Badge className="bg-blue-100 text-blue-800">En cours</Badge>
            <span>Client: Marie Dubois</span>
            <span>Freelance: Pierre Dupont</span>
          </div>
        </div>

        {/* Progress Overview */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Progression du projet</CardTitle>
                <CardDescription>Étapes complétées et à venir</CardDescription>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-blue-600">{progress}%</div>
                <p className="text-sm text-gray-600">Complété</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Progress value={progress} className="mb-4" />
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <div className="font-medium">Phase actuelle</div>
                <div className="text-gray-600">Développement frontend</div>
              </div>
              <div className="text-center">
                <div className="font-medium">Échéance</div>
                <div className="text-gray-600">15 juillet 2025</div>
              </div>
              <div className="text-center">
                <div className="font-medium">Budget</div>
                <div className="text-gray-600">3,500€</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs defaultValue="messages" className="space-y-6">
          <TabsList>
            <TabsTrigger value="messages">
              <MessageSquare className="h-4 w-4 mr-2" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="files">
              <FileText className="h-4 w-4 mr-2" />
              Fichiers
            </TabsTrigger>
            <TabsTrigger value="milestones">
              <Calendar className="h-4 w-4 mr-2" />
              Étapes
            </TabsTrigger>
            <TabsTrigger value="payments">
              <DollarSign className="h-4 w-4 mr-2" />
              Paiements
            </TabsTrigger>
          </TabsList>

          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <CardTitle>Messagerie du projet</CardTitle>
                <CardDescription>
                  Communiquez directement avec votre équipe
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-4 h-96 overflow-y-auto">
                  {/* Message Examples */}
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm">
                      MD
                    </div>
                    <div className="flex-1">
                      <div className="bg-gray-100 rounded-lg p-3">
                        <p className="text-sm">Bonjour Pierre, j'ai hâte de voir les premiers designs ! 😊</p>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">Marie Dubois • Il y a 2 heures</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3 justify-end">
                    <div className="flex-1 text-right">
                      <div className="bg-blue-500 text-white rounded-lg p-3 inline-block">
                        <p className="text-sm">Parfait ! Je vous envoie la première version ce soir.</p>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">Pierre Dupont • Il y a 1 heure</p>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white text-sm">
                      PD
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <input 
                    type="text" 
                    placeholder="Tapez votre message..."
                    className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <Button>Envoyer</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="files">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Fichiers partagés</CardTitle>
                    <CardDescription>
                      Documents, assets et livrables du projet
                    </CardDescription>
                  </div>
                  <Button>
                    <Upload className="h-4 w-4 mr-2" />
                    Uploader
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { name: 'Cahier des charges.pdf', size: '2.3 MB', date: 'Il y a 3 jours' },
                    { name: 'Maquettes_V1.fig', size: '15.7 MB', date: 'Il y a 2 jours' },
                    { name: 'Logo_final.svg', size: '0.8 MB', date: 'Il y a 1 jour' }
                  ].map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <FileText className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="font-medium">{file.name}</p>
                          <p className="text-sm text-gray-500">{file.size} • {file.date}</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="milestones">
            <Card>
              <CardHeader>
                <CardTitle>Étapes du projet</CardTitle>
                <CardDescription>
                  Suivi des jalons et livrables
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { title: 'Analyse et spécifications', status: 'completed', date: '15 juin 2025', amount: 500 },
                    { title: 'Développement frontend', status: 'in_progress', date: '30 juin 2025', amount: 1500 },
                    { title: 'Backend et intégrations', status: 'pending', date: '15 juillet 2025', amount: 1000 },
                    { title: 'Tests et déploiement', status: 'pending', date: '30 juillet 2025', amount: 500 }
                  ].map((milestone, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${
                          milestone.status === 'completed' ? 'bg-green-500' : 
                          milestone.status === 'in_progress' ? 'bg-blue-500' : 'bg-gray-300'
                        }`} />
                        <div>
                          <p className="font-medium">{milestone.title}</p>
                          <p className="text-sm text-gray-500">Échéance: {milestone.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{milestone.amount}€</p>
                        <Badge variant={
                          milestone.status === 'completed' ? 'default' :
                          milestone.status === 'in_progress' ? 'outline' : 'secondary'
                        }>
                          {milestone.status === 'completed' ? 'Terminé' :
                           milestone.status === 'in_progress' ? 'En cours' : 'En attente'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle>Gestion des paiements</CardTitle>
                <CardDescription>
                  Historique et paiements en attente
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">500€</div>
                      <p className="text-sm text-gray-600">Payé</p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">1500€</div>
                      <p className="text-sm text-gray-600">En escrow</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold text-gray-600">1500€</div>
                      <p className="text-sm text-gray-600">Restant</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {[
                      { title: 'Paiement étape 1', amount: 500, status: 'paid', date: '15 juin 2025' },
                      { title: 'Paiement étape 2', amount: 1500, status: 'escrow', date: '30 juin 2025' }
                    ].map((payment, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{payment.title}</p>
                          <p className="text-sm text-gray-500">{payment.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{payment.amount}€</p>
                          <Badge variant={payment.status === 'paid' ? 'default' : 'outline'}>
                            {payment.status === 'paid' ? 'Payé' : 'En escrow'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
