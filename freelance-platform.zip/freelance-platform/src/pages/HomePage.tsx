import { Link } from 'react-router-dom'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Badge } from '../components/ui/badge'
import { 
  Search, 
  Star, 
  Users, 
  Briefcase, 
  Shield, 
  Zap, 
  CheckCircle,
  ArrowRight,
  Globe,
  Clock,
  CreditCard
} from 'lucide-react'
import { useState } from 'react'

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('')

  const features = [
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: "Paiements sécurisés",
      description: "Système d'escrow et paiements protégés pour tous vos projets"
    },
    {
      icon: <Zap className="h-8 w-8 text-blue-600" />,
      title: "Matching intelligent",
      description: "IA avancée pour connecter les bons talents aux bonnes missions"
    },
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      title: "WorkRooms collaboratifs",
      description: "Espaces de travail dédiés avec outils de communication intégrés"
    },
    {
      icon: <Star className="h-8 w-8 text-blue-600" />,
      title: "Système d'évaluation",
      description: "Avis et notes pour garantir la qualité des prestations"
    }
  ]

  const categories = [
    { name: "Développement Web", count: "1,245 missions", color: "bg-blue-100 text-blue-800" },
    { name: "Design Graphique", count: "892 missions", color: "bg-purple-100 text-purple-800" },
    { name: "Rédaction", count: "567 missions", color: "bg-green-100 text-green-800" },
    { name: "Marketing Digital", count: "743 missions", color: "bg-orange-100 text-orange-800" },
    { name: "Traduction", count: "234 missions", color: "bg-pink-100 text-pink-800" },
    { name: "Consultation", count: "456 missions", color: "bg-indigo-100 text-indigo-800" }
  ]

  const topFreelancers = [
    {
      name: "Marie Dubois",
      specialty: "Développeuse Full-Stack",
      rating: 4.9,
      projects: 127,
      avatar: "/images/default-avatar.jpg"
    },
    {
      name: "Thomas Martin",
      specialty: "Designer UI/UX",
      rating: 4.8,
      projects: 89,
      avatar: "/images/default-avatar.jpg"
    },
    {
      name: "Sophie Laurent",
      specialty: "Rédactrice Web",
      rating: 5.0,
      projects: 156,
      avatar: "/images/default-avatar.jpg"
    }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                Trouvez les meilleurs
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
                  {" "}freelances
                </span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Connectez-vous avec des talents exceptionnels ou développez votre 
                carrière de freelance sur la plateforme la plus moderne du marché.
              </p>
              
              {/* Search Bar */}
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    type="text"
                    placeholder="Rechercher des freelances ou des missions..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12 text-lg"
                  />
                </div>
                <Button size="lg" className="h-12 px-8">
                  <Search className="h-5 w-5 mr-2" />
                  Rechercher
                </Button>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="text-lg px-8">
                  <Link to="/register">
                    Rejoindre maintenant
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="text-lg px-8">
                  <Link to="/jobs">
                    Explorer les missions
                  </Link>
                </Button>
              </div>
            </div>

            <div className="relative">
              <img
                src="/images/hero-freelancer.jpg"
                alt="Freelancer travaillant"
                className="rounded-2xl shadow-2xl w-full h-[400px] object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl p-4 shadow-lg">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span className="font-semibold">+10,000 projets réalisés</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl md:text-4xl font-bold text-blue-600 mb-2">10K+</div>
              <div className="text-gray-600">Freelances actifs</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-blue-600 mb-2">25K+</div>
              <div className="text-gray-600">Missions réalisées</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-blue-600 mb-2">98%</div>
              <div className="text-gray-600">Satisfaction client</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl font-bold text-blue-600 mb-2">24/7</div>
              <div className="text-gray-600">Support disponible</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Pourquoi choisir FreelancePro ?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Une plateforme complète avec tous les outils nécessaires pour 
              réussir vos projets freelance.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Explorez nos catégories
            </h2>
            <p className="text-xl text-gray-600">
              Trouvez le talent parfait dans votre domaine d'expertise
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{category.name}</CardTitle>
                    <CardDescription>{category.count}</CardDescription>
                  </div>
                  <Badge className={category.color}>
                    Voir plus
                  </Badge>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Top Freelancers Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nos freelances stars
            </h2>
            <p className="text-xl text-gray-600">
              Découvrez les talents les mieux notés de notre communauté
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {topFreelancers.map((freelancer, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <img
                    src={freelancer.avatar}
                    alt={freelancer.name}
                    className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                  />
                  <CardTitle>{freelancer.name}</CardTitle>
                  <CardDescription>{freelancer.specialty}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      {freelancer.rating}
                    </div>
                    <div className="flex items-center">
                      <Briefcase className="h-4 w-4 mr-1" />
                      {freelancer.projects} projets
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How it works Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Comment ça marche ?
            </h2>
            <p className="text-xl text-gray-600">
              Un processus simple en 3 étapes pour démarrer votre projet
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                1
              </div>
              <h3 className="text-xl font-semibold mb-4">Publiez votre projet</h3>
              <p className="text-gray-600">
                Décrivez votre besoin et recevez des propositions de freelances qualifiés
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                2
              </div>
              <h3 className="text-xl font-semibold mb-4">Choisissez votre freelance</h3>
              <p className="text-gray-600">
                Comparez les profils, portfolios et tarifs pour faire le meilleur choix
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                3
              </div>
              <h3 className="text-xl font-semibold mb-4">Collaborez et payez</h3>
              <p className="text-gray-600">
                Travaillez ensemble dans nos WorkRooms et payez en toute sécurité
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Prêt à démarrer votre prochain projet ?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Rejoignez des milliers de clients et freelances qui font confiance à FreelancePro
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary" className="text-lg px-8">
              <Link to="/register">
                S'inscrire gratuitement
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-lg px-8 text-white border-white hover:bg-white hover:text-blue-600">
              <Link to="/jobs">
                Explorer les missions
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
