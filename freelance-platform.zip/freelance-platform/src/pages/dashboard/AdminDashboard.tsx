import { useState, useEffect } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { createClient } from '../../lib/supabase-client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { Input } from '../../components/ui/input'
import { 
  Users, 
  Briefcase, 
  DollarSign, 
  TrendingUp,
  AlertTriangle,
  Eye,
  Ban,
  CheckCircle,
  Settings,
  Search,
  Filter,
  Download,
  MessageSquare,
  Star,
  Calendar
} from 'lucide-react'

interface User {
  id: string
  email: string
  first_name: string
  last_name: string
  role: string
  created_at: string
  is_verified: boolean
  last_seen?: string
}

interface Job {
  id: string
  title: string
  description: string
  budget: number
  budget_type: string
  status: string
  created_at: string
  client_name: string
  category: string
}

interface Transaction {
  id: string
  amount: number
  type: string
  status: string
  created_at: string
  client_name: string
  freelancer_name: string
}

export default function AdminDashboard() {
  const { userProfile } = useAuth()
  const [users, setUsers] = useState<User[]>([])
  const [jobs, setJobs] = useState<Job[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalJobs: 0,
    totalRevenue: 0,
    pendingDisputes: 0,
    monthlyGrowth: 0
  })

  const supabase = createClient()

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)

      // Fetch users
      const { data: usersData } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10)

      if (usersData) {
        setUsers(usersData)
      }

      // Fetch jobs with client info
      const { data: jobsData } = await supabase
        .from('jobs')
        .select(`
          *,
          users:client_id (first_name, last_name)
        `)
        .order('created_at', { ascending: false })
        .limit(10)

      if (jobsData) {
        const jobsWithClientName = jobsData.map(job => ({
          ...job,
          client_name: `${job.users?.first_name} ${job.users?.last_name}`
        }))
        setJobs(jobsWithClientName)
      }

      // Mock transactions data
      setTransactions([
        {
          id: '1',
          amount: 1500,
          type: 'payment',
          status: 'completed',
          created_at: '2025-06-20T10:30:00Z',
          client_name: 'Marie Martin',
          freelancer_name: 'Pierre Dupont'
        },
        {
          id: '2',
          amount: 800,
          type: 'payment',
          status: 'pending',
          created_at: '2025-06-21T14:20:00Z',
          client_name: 'Thomas Dubois',
          freelancer_name: 'Sophie Laurent'
        }
      ])

      // Calculate stats
      const totalUsers = usersData?.length || 0
      const totalJobs = jobsData?.length || 0

      setStats({
        totalUsers: 1247,
        totalJobs: 3456,
        totalRevenue: 156780,
        pendingDisputes: 3,
        monthlyGrowth: 12.5
      })

    } catch (error) {
      console.error('Erreur lors du chargement des données:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string, type: 'user' | 'job' | 'transaction' = 'job') => {
    if (type === 'user') {
      return status ? (
        <Badge className="bg-green-100 text-green-800">Vérifié</Badge>
      ) : (
        <Badge className="bg-yellow-100 text-yellow-800">En attente</Badge>
      )
    }

    if (type === 'transaction') {
      const statusMap = {
        'completed': { label: 'Terminé', color: 'bg-green-100 text-green-800' },
        'pending': { label: 'En attente', color: 'bg-yellow-100 text-yellow-800' },
        'failed': { label: 'Échoué', color: 'bg-red-100 text-red-800' }
      }
      const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.pending
      return <Badge className={statusInfo.color}>{statusInfo.label}</Badge>
    }

    const statusMap = {
      'open': { label: 'Ouvert', color: 'bg-green-100 text-green-800' },
      'in_progress': { label: 'En cours', color: 'bg-blue-100 text-blue-800' },
      'completed': { label: 'Terminé', color: 'bg-gray-100 text-gray-800' },
      'cancelled': { label: 'Annulé', color: 'bg-red-100 text-red-800' },
      'draft': { label: 'Brouillon', color: 'bg-yellow-100 text-yellow-800' }
    }
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.open
    return <Badge className={statusInfo.color}>{statusInfo.label}</Badge>
  }

  const getRoleBadge = (role: string) => {
    const roleMap = {
      'admin': { label: 'Admin', color: 'bg-purple-100 text-purple-800' },
      'client': { label: 'Client', color: 'bg-blue-100 text-blue-800' },
      'freelancer': { label: 'Freelance', color: 'bg-green-100 text-green-800' }
    }
    const roleInfo = roleMap[role as keyof typeof roleMap] || roleMap.client
    return <Badge className={roleInfo.color}>{roleInfo.label}</Badge>
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Administration FreelancePro
          </h1>
          <p className="text-gray-600 mt-2">
            Tableau de bord administrateur - Gérez la plateforme
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Utilisateurs totaux</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{stats.monthlyGrowth}% ce mois
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Missions totales</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalJobs.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                Actives et terminées
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenus totaux</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalRevenue.toLocaleString()}€</div>
              <p className="text-xs text-muted-foreground">
                Commissions perçues
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Litiges en cours</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{stats.pendingDisputes}</div>
              <p className="text-xs text-muted-foreground">
                Nécessitent une attention
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Croissance</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">+{stats.monthlyGrowth}%</div>
              <p className="text-xs text-muted-foreground">
                Nouveaux utilisateurs
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList>
            <TabsTrigger value="users">Utilisateurs</TabsTrigger>
            <TabsTrigger value="jobs">Missions</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="disputes">Litiges</TabsTrigger>
            <TabsTrigger value="settings">Paramètres</TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Gestion des utilisateurs</h2>
                <div className="flex space-x-2">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Exporter
                  </Button>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtres
                  </Button>
                </div>
              </div>

              <div className="flex space-x-4">
                <div className="flex-1">
                  <Input
                    placeholder="Rechercher un utilisateur..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
              </div>

              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Utilisateur
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Rôle
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Inscription
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {users.map((user) => (
                          <tr key={user.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div>
                                <div className="font-medium text-gray-900">
                                  {user.first_name} {user.last_name}
                                </div>
                                <div className="text-sm text-gray-500">{user.email}</div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {getRoleBadge(user.role)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {getStatusBadge(user.is_verified, 'user')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(user.created_at).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="sm">
                                <Ban className="h-4 w-4" />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Jobs Tab */}
          <TabsContent value="jobs">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Gestion des missions</h2>
                <div className="flex space-x-2">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Exporter
                  </Button>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtres
                  </Button>
                </div>
              </div>

              <div className="grid gap-6">
                {jobs.map((job) => (
                  <Card key={job.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{job.title}</CardTitle>
                          <CardDescription>
                            Par {job.client_name} • {job.category}
                          </CardDescription>
                        </div>
                        {getStatusBadge(job.status)}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4 line-clamp-2">
                        {job.description}
                      </p>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 mr-1" />
                            {job.budget.toLocaleString()}€ 
                            {job.budget_type === 'hourly' ? '/h' : ' fixe'}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            {new Date(job.created_at).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-2" />
                            Voir
                          </Button>
                          <Button variant="outline" size="sm">
                            Modérer
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Transactions Tab */}
          <TabsContent value="transactions">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Transactions et paiements</h2>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Rapport financier
                </Button>
              </div>

              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Transaction
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Montant
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {transactions.map((transaction) => (
                          <tr key={transaction.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div>
                                <div className="font-medium text-gray-900">
                                  {transaction.client_name} → {transaction.freelancer_name}
                                </div>
                                <div className="text-sm text-gray-500">ID: {transaction.id}</div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="font-medium text-gray-900">
                                {transaction.amount.toLocaleString()}€
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {getStatusBadge(transaction.status, 'transaction')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(transaction.created_at).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Disputes Tab */}
          <TabsContent value="disputes">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Gestion des litiges</h2>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      Aucun litige actif
                    </h3>
                    <p className="text-gray-600">
                      Les litiges apparaîtront ici quand ils seront signalés
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Paramètres de la plateforme</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Commission de la plateforme</CardTitle>
                    <CardDescription>
                      Pourcentage prélevé sur chaque transaction
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      <Input type="number" defaultValue="10" className="w-20" />
                      <span>%</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Délai de validation des paiements</CardTitle>
                    <CardDescription>
                      Temps avant libération automatique des fonds
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      <Input type="number" defaultValue="7" className="w-20" />
                      <span>jours</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Notifications</CardTitle>
                    <CardDescription>
                      Gérer les notifications de la plateforme
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button>
                      <Settings className="h-4 w-4 mr-2" />
                      Configurer
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Maintenance</CardTitle>
                    <CardDescription>
                      Outils de maintenance et sauvegarde
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full">
                        Sauvegarder la base de données
                      </Button>
                      <Button variant="outline" className="w-full">
                        Nettoyer les fichiers temporaires
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
