import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'

export default function DashboardPage() {
  const { userProfile, loading } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    if (!loading && userProfile) {
      switch (userProfile.role) {
        case 'admin':
          navigate('/dashboard/admin', { replace: true })
          break
        case 'freelancer':
          navigate('/dashboard/freelancer', { replace: true })
          break
        case 'client':
          navigate('/dashboard/client', { replace: true })
          break
        default:
          navigate('/dashboard/client', { replace: true })
      }
    }
  }, [userProfile, loading, navigate])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return null
}
