import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'
import { createClient } from '../../lib/supabase-client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { Progress } from '../../components/ui/progress'
import { 
  Plus,
  Briefcase, 
  Users, 
  Clock, 
  DollarSign,
  Calendar,
  MessageSquare,
  Eye,
  Star,
  TrendingUp,
  FileText
} from 'lucide-react'

interface Job {
  id: string
  title: string
  description: string
  budget: number
  budget_type: 'fixed' | 'hourly'
  category: string
  status: string
  created_at: string
  proposals_count: number
}

interface ActiveProject {
  id: string
  title: string
  freelancer_name: string
  deadline: string
  progress: number
  status: string
  budget: number
}

export default function ClientDashboard() {
  const { userProfile } = useAuth()
  const [myJobs, setMyJobs] = useState<Job[]>([])
  const [activeProjects, setActiveProjects] = useState<ActiveProject[]>([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalSpent: 0,
    activeProjects: 0,
    completedProjects: 0,
    pendingProposals: 0
  })

  const supabase = createClient()

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)

      // Fetch user's posted jobs
      const { data: jobs } = await supabase
        .from('jobs')
        .select(`
          *,
          job_proposals (id)
        `)
        .eq('client_id', userProfile?.id)
        .order('created_at', { ascending: false })
        .limit(6)

      if (jobs) {
        const jobsWithProposalCount = jobs.map(job => ({
          ...job,
          proposals_count: job.job_proposals?.length || 0
        }))
        setMyJobs(jobsWithProposalCount)
      }

      // Fetch active projects (mock data for now)
      setActiveProjects([
        {
          id: '1',
          title: 'Développement site vitrine',
          freelancer_name: 'Pierre Dupont',
          deadline: '2025-07-20',
          progress: 65,
          status: 'in_progress',
          budget: 1800
        },
        {
          id: '2',
          title: 'Logo et identité visuelle',
          freelancer_name: 'Sophie Laurent',
          deadline: '2025-07-10',
          progress: 90,
          status: 'in_progress',
          budget: 800
        }
      ])

      // Calculate stats
      const totalPendingProposals = jobsWithProposalCount?.reduce((sum, job) => sum + job.proposals_count, 0) || 0
      
      setStats({
        totalSpent: 12850,
        activeProjects: 2,
        completedProjects: 8,
        pendingProposals: totalPendingProposals
      })

    } catch (error) {
      console.error('Erreur lors du chargement des données:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'open': { label: 'Ouvert', color: 'bg-green-100 text-green-800' },
      'in_progress': { label: 'En cours', color: 'bg-blue-100 text-blue-800' },
      'completed': { label: 'Terminé', color: 'bg-gray-100 text-gray-800' },
      'cancelled': { label: 'Annulé', color: 'bg-red-100 text-red-800' },
      'draft': { label: 'Brouillon', color: 'bg-yellow-100 text-yellow-800' }
    }
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.open
    return <Badge className={statusInfo.color}>{statusInfo.label}</Badge>
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Bonjour, {userProfile?.first_name} ! 👋
            </h1>
            <p className="text-gray-600 mt-2">
              Gérez vos projets et trouvez les meilleurs freelances
            </p>
          </div>
          <Button asChild size="lg">
            <Link to="/post-job">
              <Plus className="h-5 w-5 mr-2" />
              Publier une mission
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Budget total dépensé</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalSpent.toLocaleString()}€</div>
              <p className="text-xs text-muted-foreground">
                Sur {stats.completedProjects + stats.activeProjects} projets
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Projets actifs</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeProjects}</div>
              <p className="text-xs text-muted-foreground">
                En cours de réalisation
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Projets terminés</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.completedProjects}</div>
              <p className="text-xs text-muted-foreground">
                Avec succès
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Propositions reçues</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingProposals}</div>
              <p className="text-xs text-muted-foreground">
                En attente de réponse
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="active-projects" className="space-y-6">
          <TabsList>
            <TabsTrigger value="active-projects">Projets actifs</TabsTrigger>
            <TabsTrigger value="my-jobs">Mes missions</TabsTrigger>
            <TabsTrigger value="proposals">Propositions reçues</TabsTrigger>
            <TabsTrigger value="payments">Paiements</TabsTrigger>
          </TabsList>

          {/* Active Projects Tab */}
          <TabsContent value="active-projects">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Projets en cours</h2>
                <Button variant="outline">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Rapport d'activité
                </Button>
              </div>

              {activeProjects.length > 0 ? (
                <div className="grid gap-6">
                  {activeProjects.map((project) => (
                    <Card key={project.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{project.title}</CardTitle>
                            <CardDescription>
                              Freelance: {project.freelancer_name}
                            </CardDescription>
                          </div>
                          {getStatusBadge(project.status)}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between text-sm mb-2">
                              <span>Progression</span>
                              <span>{project.progress}%</span>
                            </div>
                            <Progress value={project.progress} className="h-2" />
                          </div>
                          
                          <div className="flex justify-between items-center">
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                Échéance: {new Date(project.deadline).toLocaleDateString()}
                              </div>
                              <div className="flex items-center">
                                <DollarSign className="h-4 w-4 mr-1" />
                                {project.budget.toLocaleString()}€
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm">
                                <MessageSquare className="h-4 w-4 mr-2" />
                                Messages
                              </Button>
                              <Button asChild size="sm">
                                <Link to={`/workroom/${project.id}`}>
                                  Voir le projet
                                </Link>
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-8">
                      <Briefcase className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        Aucun projet actif
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Publiez votre première mission pour commencer
                      </p>
                      <Button asChild>
                        <Link to="/post-job">
                          <Plus className="h-4 w-4 mr-2" />
                          Publier une mission
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* My Jobs Tab */}
          <TabsContent value="my-jobs">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Mes missions publiées</h2>
                <Button asChild>
                  <Link to="/post-job">
                    <Plus className="h-4 w-4 mr-2" />
                    Nouvelle mission
                  </Link>
                </Button>
              </div>

              {myJobs.length > 0 ? (
                <div className="grid gap-6">
                  {myJobs.map((job) => (
                    <Card key={job.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <CardTitle className="text-xl">{job.title}</CardTitle>
                            <CardDescription className="mt-2">
                              {job.category} • Publié le {new Date(job.created_at).toLocaleDateString()}
                            </CardDescription>
                          </div>
                          {getStatusBadge(job.status)}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 mb-4 line-clamp-2">
                          {job.description}
                        </p>
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center">
                              <DollarSign className="h-4 w-4 mr-1" />
                              {job.budget.toLocaleString()}€ 
                              {job.budget_type === 'hourly' ? '/h' : ' fixe'}
                            </div>
                            <div className="flex items-center">
                              <Users className="h-4 w-4 mr-1" />
                              {job.proposals_count} propositions
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-2" />
                              Voir les propositions
                            </Button>
                            <Button asChild size="sm">
                              <Link to={`/jobs/${job.id}`}>
                                Gérer
                              </Link>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-8">
                      <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        Aucune mission publiée
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Commencez par publier votre première mission
                      </p>
                      <Button asChild>
                        <Link to="/post-job">
                          <Plus className="h-4 w-4 mr-2" />
                          Publier une mission
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Proposals Tab */}
          <TabsContent value="proposals">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Propositions reçues</h2>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      Aucune proposition en attente
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Les propositions apparaîtront ici quand les freelances postuleront à vos missions
                    </p>
                    <Button asChild>
                      <Link to="/post-job">
                        Publier une mission
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Paiements et facturation</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Budget ce mois</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600 mb-2">
                      2,600€
                    </div>
                    <p className="text-sm text-gray-600">
                      Dépensé sur 3 projets
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Paiements en attente</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-orange-600 mb-2">
                      800€
                    </div>
                    <p className="text-sm text-gray-600">
                      1 milestone à valider
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
