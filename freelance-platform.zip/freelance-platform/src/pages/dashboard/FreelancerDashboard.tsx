import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'
import { createClient } from '../../lib/supabase-client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '../../components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { Progress } from '../../components/ui/progress'
import { 
  Briefcase, 
  DollarSign, 
  Star, 
  Clock, 
  Calendar,
  Plus,
  Search,
  Filter,
  MessageSquare,
  Eye,
  TrendingUp,
  Award
} from 'lucide-react'

interface Job {
  id: string
  title: string
  description: string
  budget: number
  budget_type: 'fixed' | 'hourly'
  category: string
  status: string
  client_name: string
  created_at: string
  proposals_count: number
}

interface ActiveProject {
  id: string
  title: string
  client_name: string
  deadline: string
  progress: number
  status: string
  budget: number
}

export default function FreelancerDashboard() {
  const { userProfile } = useAuth()
  const [availableJobs, setAvailableJobs] = useState<Job[]>([])
  const [activeProjects, setActiveProjects] = useState<ActiveProject[]>([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalEarnings: 0,
    activeProjects: 0,
    completedProjects: 0,
    rating: 4.8
  })

  const supabase = createClient()

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)

      // Fetch available jobs
      const { data: jobs } = await supabase
        .from('jobs')
        .select(`
          *,
          users:client_id (first_name, last_name),
          job_proposals (id)
        `)
        .eq('status', 'open')
        .order('created_at', { ascending: false })
        .limit(6)

      if (jobs) {
        const jobsWithProposalCount = jobs.map(job => ({
          ...job,
          client_name: `${job.users?.first_name} ${job.users?.last_name}`,
          proposals_count: job.job_proposals?.length || 0
        }))
        setAvailableJobs(jobsWithProposalCount)
      }

      // Fetch active projects (mock data for now)
      setActiveProjects([
        {
          id: '1',
          title: 'Site e-commerce React',
          client_name: 'Marie Martin',
          deadline: '2025-07-15',
          progress: 75,
          status: 'in_progress',
          budget: 2500
        },
        {
          id: '2',
          title: 'Application mobile Flutter',
          client_name: 'Thomas Dubois',
          deadline: '2025-08-01',
          progress: 30,
          status: 'in_progress',
          budget: 4500
        }
      ])

      // Fetch stats (mock data for now)
      setStats({
        totalEarnings: 15420,
        activeProjects: 2,
        completedProjects: 24,
        rating: 4.9
      })

    } catch (error) {
      console.error('Erreur lors du chargement des données:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'open': { label: 'Ouvert', color: 'bg-green-100 text-green-800' },
      'in_progress': { label: 'En cours', color: 'bg-blue-100 text-blue-800' },
      'completed': { label: 'Terminé', color: 'bg-gray-100 text-gray-800' },
      'cancelled': { label: 'Annulé', color: 'bg-red-100 text-red-800' }
    }
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.open
    return <Badge className={statusInfo.color}>{statusInfo.label}</Badge>
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Bonjour, {userProfile?.first_name} ! 👋
          </h1>
          <p className="text-gray-600 mt-2">
            Voici un aperçu de vos activités et opportunités
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Gains totaux</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalEarnings.toLocaleString()}€</div>
              <p className="text-xs text-muted-foreground">
                +12% par rapport au mois dernier
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Projets actifs</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeProjects}</div>
              <p className="text-xs text-muted-foreground">
                En cours de réalisation
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Projets terminés</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.completedProjects}</div>
              <p className="text-xs text-muted-foreground">
                Avec succès
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Note moyenne</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.rating}/5</div>
              <p className="text-xs text-muted-foreground">
                Basé sur {stats.completedProjects} avis
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="opportunities" className="space-y-6">
          <TabsList>
            <TabsTrigger value="opportunities">Opportunités</TabsTrigger>
            <TabsTrigger value="active-projects">Projets actifs</TabsTrigger>
            <TabsTrigger value="proposals">Mes propositions</TabsTrigger>
            <TabsTrigger value="earnings">Revenus</TabsTrigger>
          </TabsList>

          {/* Opportunities Tab */}
          <TabsContent value="opportunities">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Missions disponibles</h2>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtres
                  </Button>
                  <Button asChild>
                    <Link to="/jobs">
                      <Search className="h-4 w-4 mr-2" />
                      Voir toutes les missions
                    </Link>
                  </Button>
                </div>
              </div>

              <div className="grid gap-6">
                {availableJobs.map((job) => (
                  <Card key={job.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <CardTitle className="text-xl">{job.title}</CardTitle>
                          <CardDescription className="mt-2">
                            Par {job.client_name} • {job.category}
                          </CardDescription>
                        </div>
                        {getStatusBadge(job.status)}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4 line-clamp-2">
                        {job.description}
                      </p>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 mr-1" />
                            {job.budget.toLocaleString()}€ 
                            {job.budget_type === 'hourly' ? '/h' : ' fixe'}
                          </div>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            Publié {new Date(job.created_at).toLocaleDateString()}
                          </div>
                          <div className="flex items-center">
                            <Eye className="h-4 w-4 mr-1" />
                            {job.proposals_count} propositions
                          </div>
                        </div>
                        <Button asChild>
                          <Link to={`/jobs/${job.id}`}>
                            Voir les détails
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Active Projects Tab */}
          <TabsContent value="active-projects">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Projets en cours</h2>
                <Button variant="outline">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Rapport d'activité
                </Button>
              </div>

              <div className="grid gap-6">
                {activeProjects.map((project) => (
                  <Card key={project.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{project.title}</CardTitle>
                          <CardDescription>
                            Client: {project.client_name}
                          </CardDescription>
                        </div>
                        {getStatusBadge(project.status)}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span>Progression</span>
                            <span>{project.progress}%</span>
                          </div>
                          <Progress value={project.progress} className="h-2" />
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center">
                              <Calendar className="h-4 w-4 mr-1" />
                              Échéance: {new Date(project.deadline).toLocaleDateString()}
                            </div>
                            <div className="flex items-center">
                              <DollarSign className="h-4 w-4 mr-1" />
                              {project.budget.toLocaleString()}€
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <MessageSquare className="h-4 w-4 mr-2" />
                              Messages
                            </Button>
                            <Button asChild size="sm">
                              <Link to={`/workroom/${project.id}`}>
                                Accéder au projet
                              </Link>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Proposals Tab */}
          <TabsContent value="proposals">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Mes propositions</h2>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <Briefcase className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      Aucune proposition envoyée
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Commencez à postuler pour des missions qui vous intéressent
                    </p>
                    <Button asChild>
                      <Link to="/jobs">
                        Parcourir les missions
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Earnings Tab */}
          <TabsContent value="earnings">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Revenus et paiements</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Revenus ce mois</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600 mb-2">
                      3,240€
                    </div>
                    <p className="text-sm text-gray-600">
                      +15% par rapport au mois dernier
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Paiements en attente</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-orange-600 mb-2">
                      1,200€
                    </div>
                    <p className="text-sm text-gray-600">
                      2 factures en cours de traitement
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
