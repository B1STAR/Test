import { useState } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Textarea } from '../../components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '../../components/ui/avatar'
import { Badge } from '../../components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Edit, 
  Save,
  Camera,
  Star,
  Briefcase
} from 'lucide-react'
import { useToast } from '../../hooks/use-toast'

export default function ProfilePage() {
  const { userProfile, updateProfile } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    first_name: userProfile?.first_name || '',
    last_name: userProfile?.last_name || '',
    email: userProfile?.email || '',
    phone: userProfile?.phone || '',
    location: userProfile?.location || '',
    avatar_url: userProfile?.avatar_url || ''
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      const { error } = await updateProfile(formData)
      
      if (error) {
        throw error
      }

      toast({
        title: "Profil mis à jour",
        description: "Vos informations ont été sauvegardées avec succès.",
      })
      setIsEditing(false)
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la mise à jour.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleCancel = () => {
    setFormData({
      first_name: userProfile?.first_name || '',
      last_name: userProfile?.last_name || '',
      email: userProfile?.email || '',
      phone: userProfile?.phone || '',
      location: userProfile?.location || '',
      avatar_url: userProfile?.avatar_url || ''
    })
    setIsEditing(false)
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Mon Profil</h1>
          <p className="text-gray-600 mt-2">
            Gérez vos informations personnelles et paramètres de compte
          </p>
        </div>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList>
            <TabsTrigger value="general">Informations générales</TabsTrigger>
            <TabsTrigger value="professional">Profil professionnel</TabsTrigger>
            <TabsTrigger value="security">Sécurité</TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Informations personnelles</CardTitle>
                    <CardDescription>
                      Mettez à jour vos informations de base
                    </CardDescription>
                  </div>
                  {!isEditing ? (
                    <Button onClick={() => setIsEditing(true)} variant="outline">
                      <Edit className="h-4 w-4 mr-2" />
                      Modifier
                    </Button>
                  ) : (
                    <div className="flex space-x-2">
                      <Button onClick={handleCancel} variant="outline">
                        Annuler
                      </Button>
                      <Button onClick={handleSave} disabled={loading}>
                        <Save className="h-4 w-4 mr-2" />
                        {loading ? 'Sauvegarde...' : 'Sauvegarder'}
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Avatar */}
                <div className="flex items-center space-x-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={formData.avatar_url || '/images/default-avatar.jpg'} />
                    <AvatarFallback>
                      {formData.first_name?.[0]}{formData.last_name?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  {isEditing && (
                    <Button variant="outline" size="sm">
                      <Camera className="h-4 w-4 mr-2" />
                      Changer la photo
                    </Button>
                  )}
                </div>

                {/* Basic Info */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="first_name">Prénom</Label>
                    <Input
                      id="first_name"
                      value={formData.first_name}
                      onChange={(e) => handleInputChange('first_name', e.target.value)}
                      disabled={!isEditing}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="last_name">Nom</Label>
                    <Input
                      id="last_name"
                      value={formData.last_name}
                      onChange={(e) => handleInputChange('last_name', e.target.value)}
                      disabled={!isEditing}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      disabled={!isEditing}
                      className="pl-10 mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="phone">Téléphone</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      disabled={!isEditing}
                      className="pl-10 mt-1"
                      placeholder="+33 1 23 45 67 89"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="location">Localisation</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => handleInputChange('location', e.target.value)}
                      disabled={!isEditing}
                      className="pl-10 mt-1"
                      placeholder="Paris, France"
                    />
                  </div>
                </div>

                {/* Role Badge */}
                <div>
                  <Label>Rôle sur la plateforme</Label>
                  <div className="mt-2">
                    <Badge variant="outline" className="capitalize">
                      {userProfile?.role === 'freelancer' ? 'Freelance' : 
                       userProfile?.role === 'client' ? 'Client' : 'Administrateur'}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="professional">
            <Card>
              <CardHeader>
                <CardTitle>Profil professionnel</CardTitle>
                <CardDescription>
                  {userProfile?.role === 'freelancer' 
                    ? 'Gérez votre profil freelance et portfolio'
                    : 'Informations sur votre entreprise et besoins'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                {userProfile?.role === 'freelancer' ? (
                  <div className="space-y-6">
                    <div>
                      <Label>Titre professionnel</Label>
                      <Input 
                        placeholder="Ex: Développeur Full-Stack React/Node.js"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Description de votre profil</Label>
                      <Textarea 
                        placeholder="Décrivez votre expérience, vos spécialités et ce qui vous différencie..."
                        rows={4}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Tarif horaire (€)</Label>
                      <Input 
                        type="number"
                        placeholder="50"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Compétences</Label>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {['React', 'Node.js', 'TypeScript', 'MongoDB'].map((skill) => (
                          <Badge key={skill} variant="outline">{skill}</Badge>
                        ))}
                      </div>
                      <Button variant="outline" size="sm" className="mt-2">
                        Gérer les compétences
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <Label>Nom de l'entreprise</Label>
                      <Input 
                        placeholder="Mon Entreprise SAS"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Secteur d'activité</Label>
                      <Input 
                        placeholder="Ex: E-commerce, Tech, Consulting..."
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Taille de l'entreprise</Label>
                      <Input 
                        placeholder="Ex: 1-10 employés"
                        className="mt-1"
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Mot de passe</CardTitle>
                  <CardDescription>
                    Changez votre mot de passe pour sécuriser votre compte
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Mot de passe actuel</Label>
                    <Input type="password" className="mt-1" />
                  </div>
                  <div>
                    <Label>Nouveau mot de passe</Label>
                    <Input type="password" className="mt-1" />
                  </div>
                  <div>
                    <Label>Confirmer le nouveau mot de passe</Label>
                    <Input type="password" className="mt-1" />
                  </div>
                  <Button>Mettre à jour le mot de passe</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Authentification à deux facteurs</CardTitle>
                  <CardDescription>
                    Ajoutez une couche de sécurité supplémentaire à votre compte
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">2FA non activée</p>
                      <p className="text-sm text-gray-600">
                        Protégez votre compte avec l'authentification à deux facteurs
                      </p>
                    </div>
                    <Button variant="outline">Activer</Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Sessions actives</CardTitle>
                  <CardDescription>
                    Gérez vos sessions de connexion actives
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Session actuelle</p>
                        <p className="text-sm text-gray-600">
                          Paris, France • Chrome sur Windows • Maintenant
                        </p>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        Actuel
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
