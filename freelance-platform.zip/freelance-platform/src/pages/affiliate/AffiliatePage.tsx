import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Badge } from '../../components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { 
  Share2, 
  DollarSign, 
  Users, 
  TrendingUp,
  Copy,
  Eye,
  Calendar,
  Gift
} from 'lucide-react'
import { useToast } from '../../hooks/use-toast'

export default function AffiliatePage() {
  const [affiliateLink] = useState('https://freelancepro.com/ref/your-code-123')
  const { toast } = useToast()

  const copyLink = () => {
    navigator.clipboard.writeText(affiliateLink)
    toast({
      title: "Lien copié !",
      description: "Le lien d'affiliation a été copié dans le presse-papier.",
    })
  }

  const stats = {
    totalEarnings: 1250,
    pendingEarnings: 350,
    totalReferrals: 28,
    activeReferrals: 12,
    conversionRate: 12.5,
    thisMonthEarnings: 450
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Programme d'affiliation
          </h1>
          <p className="text-gray-600">
            Gagnez des commissions en recommandant FreelancePro à vos contacts
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Gains totaux</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalEarnings}€</div>
              <p className="text-xs text-muted-foreground">
                +{stats.thisMonthEarnings}€ ce mois
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">En attente</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingEarnings}€</div>
              <p className="text-xs text-muted-foreground">
                Versement le 15 du mois
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Parrainages totaux</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalReferrals}</div>
              <p className="text-xs text-muted-foreground">
                {stats.activeReferrals} actifs
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taux de conversion</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.conversionRate}%</div>
              <p className="text-xs text-muted-foreground">
                Visiteurs → Inscriptions
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
            <TabsTrigger value="links">Liens d'affiliation</TabsTrigger>
            <TabsTrigger value="earnings">Gains</TabsTrigger>
            <TabsTrigger value="referrals">Parrainages</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* How it works */}
              <Card>
                <CardHeader>
                  <CardTitle>Comment ça marche ?</CardTitle>
                  <CardDescription>
                    Gagnez jusqu'à 20% de commission sur chaque nouveau client
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                        1
                      </div>
                      <div>
                        <h4 className="font-medium">Partagez votre lien</h4>
                        <p className="text-sm text-gray-600">
                          Utilisez votre lien personnalisé pour inviter de nouveaux utilisateurs
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                        2
                      </div>
                      <div>
                        <h4 className="font-medium">Ils s'inscrivent</h4>
                        <p className="text-sm text-gray-600">
                          Vos contacts créent un compte et commencent à utiliser la plateforme
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                        3
                      </div>
                      <div>
                        <h4 className="font-medium">Vous gagnez</h4>
                        <p className="text-sm text-gray-600">
                          Recevez 20% de commission sur leurs transactions pendant 12 mois
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card>
                <CardHeader>
                  <CardTitle>Performance ce mois</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Visiteurs uniques</span>
                      <span className="font-medium">847</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Nouvelles inscriptions</span>
                      <span className="font-medium">12</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Premiers projets</span>
                      <span className="font-medium">8</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Commissions générées</span>
                      <span className="font-medium text-green-600">450€</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="links">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Votre lien d'affiliation principal</CardTitle>
                  <CardDescription>
                    Partagez ce lien pour gagner des commissions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex space-x-2">
                    <Input value={affiliateLink} readOnly className="flex-1" />
                    <Button onClick={copyLink}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copier
                    </Button>
                    <Button variant="outline">
                      <Share2 className="h-4 w-4 mr-2" />
                      Partager
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Liens personnalisés</CardTitle>
                  <CardDescription>
                    Créez des liens spécifiques pour différentes campagnes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { name: 'Réseaux sociaux', url: 'freelancepro.com/ref/social-123', clicks: 234 },
                      { name: 'Newsletter', url: 'freelancepro.com/ref/newsletter-123', clicks: 89 },
                      { name: 'Blog personnel', url: 'freelancepro.com/ref/blog-123', clicks: 156 }
                    ].map((link, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{link.name}</p>
                          <p className="text-sm text-gray-600">{link.url}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{link.clicks} clics</p>
                          <Button variant="outline" size="sm">
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button className="w-full mt-4">
                    Créer un nouveau lien
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="earnings">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Historique des gains</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { date: 'Juin 2025', amount: 450, status: 'pending' },
                      { date: 'Mai 2025', amount: 320, status: 'paid' },
                      { date: 'Avril 2025', amount: 280, status: 'paid' },
                      { date: 'Mars 2025', amount: 200, status: 'paid' }
                    ].map((earning, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Calendar className="h-5 w-5 text-gray-400" />
                          <span className="font-medium">{earning.date}</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span className="font-medium">{earning.amount}€</span>
                          <Badge variant={earning.status === 'paid' ? 'default' : 'outline'}>
                            {earning.status === 'paid' ? 'Payé' : 'En attente'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Méthode de paiement</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Virement bancaire</p>
                          <p className="text-sm text-gray-600">****1234 - Banque Exemple</p>
                        </div>
                        <Button variant="outline" size="sm">Modifier</Button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">
                      Les paiements sont effectués le 15 de chaque mois pour un minimum de 50€.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="referrals">
            <Card>
              <CardHeader>
                <CardTitle>Vos parrainages</CardTitle>
                <CardDescription>
                  Liste des utilisateurs que vous avez parrainés
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: 'Thomas Martin', date: '15 juin 2025', status: 'active', earned: 45 },
                    { name: 'Sophie Laurent', date: '12 juin 2025', status: 'active', earned: 32 },
                    { name: 'Pierre Dubois', date: '8 juin 2025', status: 'pending', earned: 0 },
                    { name: 'Marie Dupont', date: '5 juin 2025', status: 'active', earned: 78 }
                  ].map((referral, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{referral.name}</p>
                        <p className="text-sm text-gray-600">Inscrit le {referral.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{referral.earned}€ générés</p>
                        <Badge variant={referral.status === 'active' ? 'default' : 'outline'}>
                          {referral.status === 'active' ? 'Actif' : 'En attente'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
