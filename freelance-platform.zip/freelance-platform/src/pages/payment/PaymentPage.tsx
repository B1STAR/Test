import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { 
  CreditCard, 
  Shield, 
  Clock, 
  CheckCircle,
  AlertCircle
} from 'lucide-react'

export default function PaymentPage() {
  const { id } = useParams()
  const [loading, setLoading] = useState(false)

  const handlePayment = () => {
    setLoading(true)
    // Simulate payment processing
    setTimeout(() => {
      setLoading(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Paiement sécurisé
          </h1>
          <p className="text-gray-600">
            Effectuez votre paiement en toute sécurité via notre système d'escrow
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Payment Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Détails du paiement</CardTitle>
                <CardDescription>
                  Paiement pour: Développement frontend - Étape 2
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center text-blue-800">
                      <Shield className="h-5 w-5 mr-2" />
                      <span className="font-medium">Paiement sécurisé avec escrow</span>
                    </div>
                    <p className="text-blue-700 text-sm mt-1">
                      Vos fonds sont sécurisés et ne seront libérés qu'une fois le travail validé
                    </p>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h3 className="font-medium mb-4">Informations de carte</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Numéro de carte</label>
                        <div className="relative">
                          <input 
                            type="text" 
                            placeholder="1234 5678 9012 3456"
                            className="w-full px-3 py-2 border rounded-lg pr-10"
                          />
                          <CreditCard className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Date d'expiration</label>
                          <input 
                            type="text" 
                            placeholder="MM/AA"
                            className="w-full px-3 py-2 border rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">CVV</label>
                          <input 
                            type="text" 
                            placeholder="123"
                            className="w-full px-3 py-2 border rounded-lg"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-1">Nom du titulaire</label>
                        <input 
                          type="text" 
                          placeholder="Marie Dubois"
                          className="w-full px-3 py-2 border rounded-lg"
                        />
                      </div>
                    </div>
                  </div>

                  <Button 
                    className="w-full" 
                    size="lg"
                    onClick={handlePayment}
                    disabled={loading}
                  >
                    {loading ? 'Traitement en cours...' : 'Payer 1,500€'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Résumé de la commande</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Montant du projet</span>
                    <span>1,500€</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Frais de service (5%)</span>
                    <span>75€</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>1,575€</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Protection acheteur</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                    <span>Fonds sécurisés en escrow</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                    <span>Libération uniquement après validation</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                    <span>Support en cas de litige</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                    <span>Remboursement garanti</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Détails du projet</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div><strong>Projet:</strong> Développement site e-commerce</div>
                  <div><strong>Freelance:</strong> Pierre Dupont</div>
                  <div><strong>Étape:</strong> Développement frontend</div>
                  <div><strong>Échéance:</strong> 30 juin 2025</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
