import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'
import { createClient } from '../../lib/supabase-client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import { Textarea } from '../../components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select'
import { RadioGroup, RadioGroupItem } from '../../components/ui/radio-group'
import { Checkbox } from '../../components/ui/checkbox'
import { Badge } from '../../components/ui/badge'
import { Alert, AlertDescription } from '../../components/ui/alert'
import { 
  Plus, 
  X, 
  DollarSign, 
  Clock, 
  Users, 
  FileText,
  Eye,
  ArrowRight,
  ArrowLeft,
  CheckCircle
} from 'lucide-react'
import { useToast } from '../../hooks/use-toast'

const categories = [
  'Développement Web',
  'Design Graphique',
  'Rédaction',
  'Marketing Digital',
  'Traduction',
  'Consultation',
  'Photographie',
  'Vidéo et Animation'
]

const experienceLevels = [
  { value: 'beginner', label: 'Débutant', description: 'Convient aux freelances avec peu d\'expérience' },
  { value: 'intermediate', label: 'Intermédiaire', description: 'Quelques années d\'expérience requises' },
  { value: 'expert', label: 'Expert', description: 'Expertise avancée et portfolio solide nécessaires' }
]

const projectDurations = [
  'Moins d\'une semaine',
  '1-2 semaines',
  '3-4 semaines',
  '1-3 mois',
  '3-6 mois',
  'Plus de 6 mois'
]

interface JobData {
  title: string
  description: string
  category: string
  budget_type: 'fixed' | 'hourly'
  budget: number
  experience_level: 'beginner' | 'intermediate' | 'expert'
  duration: string
  location: string
  skills_required: string[]
  requirements: string[]
  deliverables: string[]
}

export default function PostJobPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [newSkill, setNewSkill] = useState('')
  const [newRequirement, setNewRequirement] = useState('')
  const [newDeliverable, setNewDeliverable] = useState('')
  const [jobData, setJobData] = useState<JobData>({
    title: '',
    description: '',
    category: '',
    budget_type: 'fixed',
    budget: 0,
    experience_level: 'intermediate',
    duration: '',
    location: 'Remote',
    skills_required: [],
    requirements: [],
    deliverables: []
  })

  const { userProfile } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()
  const supabase = createClient()

  const totalSteps = 4

  const updateJobData = (field: keyof JobData, value: any) => {
    setJobData(prev => ({ ...prev, [field]: value }))
  }

  const addItem = (field: 'skills_required' | 'requirements' | 'deliverables', value: string) => {
    if (value.trim()) {
      updateJobData(field, [...jobData[field], value.trim()])
    }
  }

  const removeItem = (field: 'skills_required' | 'requirements' | 'deliverables', index: number) => {
    const items = [...jobData[field]]
    items.splice(index, 1)
    updateJobData(field, items)
  }

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!(jobData.title && jobData.description && jobData.category)
      case 2:
        return !!(jobData.budget > 0 && jobData.experience_level && jobData.duration)
      case 3:
        return jobData.skills_required.length > 0
      case 4:
        return true
      default:
        return false
    }
  }

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, totalSteps))
    }
  }

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1))
  }

  const handleSubmit = async () => {
    setLoading(true)

    try {
      const { data, error } = await supabase
        .from('jobs')
        .insert([
          {
            ...jobData,
            client_id: userProfile?.id,
            status: 'open',
            created_at: new Date().toISOString()
          }
        ])
        .select()
        .single()

      if (error) {
        throw error
      }

      toast({
        title: "Mission publiée avec succès !",
        description: "Votre mission est maintenant visible par tous les freelances.",
      })

      navigate(`/jobs/${data.id}`)
    } catch (error) {
      console.error('Erreur lors de la publication:', error)
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la publication de votre mission.",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  // Redirect if not a client
  if (userProfile?.role !== 'client') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <h2 className="text-xl font-semibold mb-2">Accès restreint</h2>
              <p className="text-gray-600 mb-4">
                Seuls les clients peuvent publier des missions.
              </p>
              <Button onClick={() => navigate('/')}>
                Retour à l'accueil
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Publier une nouvelle mission
          </h1>
          <p className="text-gray-600">
            Trouvez le freelance parfait pour votre projet en quelques étapes
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => (
              <div
                key={step}
                className={`flex items-center ${step < totalSteps ? 'flex-1' : ''}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step <= currentStep
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {step < currentStep ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    step
                  )}
                </div>
                {step < totalSteps && (
                  <div
                    className={`flex-1 h-1 mx-4 ${
                      step < currentStep ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-sm text-gray-600">
            <span>Détails de base</span>
            <span>Budget et timing</span>
            <span>Compétences</span>
            <span>Révision</span>
          </div>
        </div>

        {/* Step Content */}
        <Card>
          <CardContent className="p-8">
            {/* Step 1: Basic Details */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Détails de la mission</h2>
                  <p className="text-gray-600 mb-6">
                    Commençons par les informations de base de votre projet.
                  </p>
                </div>

                <div>
                  <Label htmlFor="title">Titre de la mission *</Label>
                  <Input
                    id="title"
                    placeholder="Ex: Développement d'un site web e-commerce"
                    value={jobData.title}
                    onChange={(e) => updateJobData('title', e.target.value)}
                    className="mt-1"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Soyez précis et attractif pour attirer les bons freelances
                  </p>
                </div>

                <div>
                  <Label htmlFor="category">Catégorie *</Label>
                  <Select value={jobData.category} onValueChange={(value) => updateJobData('category', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Sélectionnez une catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description détaillée *</Label>
                  <Textarea
                    id="description"
                    placeholder="Décrivez votre projet en détail : objectifs, contexte, fonctionnalités attendues..."
                    value={jobData.description}
                    onChange={(e) => updateJobData('description', e.target.value)}
                    rows={8}
                    className="mt-1"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Plus votre description est détaillée, meilleures seront les propositions
                  </p>
                </div>
              </div>
            )}

            {/* Step 2: Budget and Timing */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Budget et planning</h2>
                  <p className="text-gray-600 mb-6">
                    Définissez votre budget et les contraintes de temps.
                  </p>
                </div>

                <div>
                  <Label className="text-base font-medium mb-4 block">Type de budget *</Label>
                  <RadioGroup
                    value={jobData.budget_type}
                    onValueChange={(value: 'fixed' | 'hourly') => updateJobData('budget_type', value)}
                  >
                    <div className="flex items-center space-x-2 p-4 border rounded-lg">
                      <RadioGroupItem value="fixed" id="fixed" />
                      <Label htmlFor="fixed" className="flex-1 cursor-pointer">
                        <div className="font-medium">Prix fixe</div>
                        <div className="text-sm text-gray-500">Un montant total pour l'ensemble du projet</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg">
                      <RadioGroupItem value="hourly" id="hourly" />
                      <Label htmlFor="hourly" className="flex-1 cursor-pointer">
                        <div className="font-medium">Tarif horaire</div>
                        <div className="text-sm text-gray-500">Paiement basé sur le temps de travail</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="budget">
                    Budget {jobData.budget_type === 'hourly' ? 'horaire' : 'total'} (€) *
                  </Label>
                  <div className="relative mt-1">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="budget"
                      type="number"
                      placeholder={jobData.budget_type === 'hourly' ? '50' : '2500'}
                      value={jobData.budget || ''}
                      onChange={(e) => updateJobData('budget', parseFloat(e.target.value) || 0)}
                      className="pl-10"
                    />
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    {jobData.budget_type === 'hourly' 
                      ? 'Tarif horaire que vous êtes prêt à payer'
                      : 'Budget total estimé pour le projet'
                    }
                  </p>
                </div>

                <div>
                  <Label htmlFor="experience">Niveau d'expérience requis *</Label>
                  <Select value={jobData.experience_level} onValueChange={(value: any) => updateJobData('experience_level', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {experienceLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          <div>
                            <div className="font-medium">{level.label}</div>
                            <div className="text-sm text-gray-500">{level.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="duration">Durée estimée du projet *</Label>
                  <Select value={jobData.duration} onValueChange={(value) => updateJobData('duration', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Sélectionnez une durée" />
                    </SelectTrigger>
                    <SelectContent>
                      {projectDurations.map((duration) => (
                        <SelectItem key={duration} value={duration}>
                          {duration}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="location">Localisation</Label>
                  <Input
                    id="location"
                    placeholder="Ex: Paris, Remote, France"
                    value={jobData.location}
                    onChange={(e) => updateJobData('location', e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            )}

            {/* Step 3: Skills and Requirements */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Compétences et exigences</h2>
                  <p className="text-gray-600 mb-6">
                    Précisez les compétences nécessaires et vos attentes.
                  </p>
                </div>

                <div>
                  <Label>Compétences requises *</Label>
                  <div className="mt-2">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Ex: React, Node.js, MongoDB..."
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault()
                            addItem('skills_required', newSkill)
                            setNewSkill('')
                          }
                        }}
                      />
                      <Button 
                        type="button"
                        onClick={() => {
                          addItem('skills_required', newSkill)
                          setNewSkill('')
                        }}
                        disabled={!newSkill.trim()}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-3">
                      {jobData.skills_required.map((skill, index) => (
                        <Badge key={index} variant="outline" className="pl-2 pr-1">
                          {skill}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-auto p-1 ml-1"
                            onClick={() => removeItem('skills_required', index)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Exigences spécifiques</Label>
                  <div className="mt-2">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Ex: Expérience avec des projets e-commerce..."
                        value={newRequirement}
                        onChange={(e) => setNewRequirement(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault()
                            addItem('requirements', newRequirement)
                            setNewRequirement('')
                          }
                        }}
                      />
                      <Button 
                        type="button"
                        onClick={() => {
                          addItem('requirements', newRequirement)
                          setNewRequirement('')
                        }}
                        disabled={!newRequirement.trim()}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-2 mt-3">
                      {jobData.requirements.map((requirement, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                          <span className="text-sm">{requirement}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem('requirements', index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Livrables attendus</Label>
                  <div className="mt-2">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Ex: Code source documenté, tests inclus..."
                        value={newDeliverable}
                        onChange={(e) => setNewDeliverable(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault()
                            addItem('deliverables', newDeliverable)
                            setNewDeliverable('')
                          }
                        }}
                      />
                      <Button 
                        type="button"
                        onClick={() => {
                          addItem('deliverables', newDeliverable)
                          setNewDeliverable('')
                        }}
                        disabled={!newDeliverable.trim()}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-2 mt-3">
                      {jobData.deliverables.map((deliverable, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                          <span className="text-sm">{deliverable}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem('deliverables', index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Review */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold mb-4">Révision de votre mission</h2>
                  <p className="text-gray-600 mb-6">
                    Vérifiez tous les détails avant de publier votre mission.
                  </p>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>{jobData.title}</CardTitle>
                    <CardDescription>{jobData.category}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Description</h4>
                      <p className="text-gray-600 text-sm">{jobData.description}</p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium mb-2">Budget</h4>
                        <p className="text-lg font-semibold text-green-600">
                          {jobData.budget.toLocaleString()}€{jobData.budget_type === 'hourly' ? '/h' : ''}
                        </p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Durée</h4>
                        <p className="text-gray-600">{jobData.duration}</p>
                      </div>
                    </div>

                    {jobData.skills_required.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Compétences requises</h4>
                        <div className="flex flex-wrap gap-2">
                          {jobData.skills_required.map((skill, index) => (
                            <Badge key={index} variant="outline">{skill}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Alert>
                  <Eye className="h-4 w-4" />
                  <AlertDescription>
                    Votre mission sera visible par tous les freelances de la plateforme. 
                    Vous recevrez des propositions que vous pourrez examiner et comparer.
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t">
              <Button 
                variant="outline" 
                onClick={prevStep}
                disabled={currentStep === 1}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Précédent
              </Button>

              {currentStep < totalSteps ? (
                <Button 
                  onClick={nextStep}
                  disabled={!validateStep(currentStep)}
                >
                  Suivant
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                <Button 
                  onClick={handleSubmit}
                  disabled={loading || !validateStep(currentStep)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {loading ? 'Publication...' : 'Publier la mission'}
                  <CheckCircle className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
