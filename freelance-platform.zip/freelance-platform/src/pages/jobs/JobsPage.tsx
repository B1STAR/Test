import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { createClient } from '../../lib/supabase-client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Badge } from '../../components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select'
import { Checkbox } from '../../components/ui/checkbox'
import { Label } from '../../components/ui/label'
import { Separator } from '../../components/ui/separator'
import { 
  Search, 
  Filter, 
  MapPin, 
  Clock, 
  DollarSign, 
  Users, 
  Calendar,
  Star,
  Eye,
  Briefcase,
  Grid,
  List
} from 'lucide-react'

interface Job {
  id: string
  title: string
  description: string
  budget: number
  budget_type: 'fixed' | 'hourly'
  category: string
  status: string
  created_at: string
  client_name: string
  client_avatar?: string
  client_rating?: number
  location?: string
  skills_required: string[]
  experience_level: 'beginner' | 'intermediate' | 'expert'
  duration?: string
  proposals_count: number
}

const categories = [
  'Développement Web',
  'Design Graphique',
  'Rédaction',
  'Marketing Digital',
  'Traduction',
  'Consultation',
  'Photographie',
  'Vidéo et Animation'
]

const experienceLevels = [
  { value: 'beginner', label: 'Débutant' },
  { value: 'intermediate', label: 'Intermédiaire' },
  { value: 'expert', label: 'Expert' }
]

const budgetRanges = [
  { value: '0-500', label: 'Moins de 500€' },
  { value: '500-1000', label: '500€ - 1000€' },
  { value: '1000-2500', label: '1000€ - 2500€' },
  { value: '2500-5000', label: '2500€ - 5000€' },
  { value: '5000+', label: 'Plus de 5000€' }
]

export default function JobsPage() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [selectedExperience, setSelectedExperience] = useState('')
  const [selectedBudgetRange, setSelectedBudgetRange] = useState('')
  const [selectedBudgetType, setSelectedBudgetType] = useState('')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sortBy, setSortBy] = useState('newest')

  const supabase = createClient()

  useEffect(() => {
    fetchJobs()
  }, [])

  useEffect(() => {
    filterJobs()
  }, [searchTerm, selectedCategory, selectedExperience, selectedBudgetRange, selectedBudgetType, sortBy])

  const fetchJobs = async () => {
    try {
      setLoading(true)

      // For now, we'll use mock data since the jobs table might not have all fields
      const mockJobs: Job[] = [
        {
          id: '1',
          title: 'Développement d\'une application e-commerce',
          description: 'Nous recherchons un développeur expérimenté pour créer une plateforme e-commerce complète avec React et Node.js. Le projet inclut la gestion des produits, des commandes, des paiements et un back-office administrateur.',
          budget: 3500,
          budget_type: 'fixed',
          category: 'Développement Web',
          status: 'open',
          created_at: '2025-06-20T10:00:00Z',
          client_name: 'Marie Dubois',
          client_rating: 4.8,
          location: 'France',
          skills_required: ['React', 'Node.js', 'MongoDB', 'Stripe'],
          experience_level: 'expert',
          duration: '2-3 mois',
          proposals_count: 12
        },
        {
          id: '2',
          title: 'Création d\'une identité visuelle complète',
          description: 'Startup tech cherche designer pour créer logo, charte graphique et supports de communication. Style moderne et épuré recherché.',
          budget: 1200,
          budget_type: 'fixed',
          category: 'Design Graphique',
          status: 'open',
          created_at: '2025-06-21T14:30:00Z',
          client_name: 'Thomas Martin',
          client_rating: 4.9,
          location: 'Paris',
          skills_required: ['Illustrator', 'Photoshop', 'Branding'],
          experience_level: 'intermediate',
          duration: '3-4 semaines',
          proposals_count: 8
        },
        {
          id: '3',
          title: 'Rédaction d\'articles de blog SEO',
          description: 'Besoin d\'un rédacteur web pour produire 20 articles de blog optimisés SEO dans le domaine de la tech. 800-1000 mots par article.',
          budget: 25,
          budget_type: 'hourly',
          category: 'Rédaction',
          status: 'open',
          created_at: '2025-06-22T09:15:00Z',
          client_name: 'Sophie Laurent',
          client_rating: 4.7,
          location: 'Remote',
          skills_required: ['SEO', 'Rédaction web', 'WordPress'],
          experience_level: 'intermediate',
          duration: '1 mois',
          proposals_count: 15
        },
        {
          id: '4',
          title: 'Développement d\'une application mobile',
          description: 'Application mobile pour la livraison de repas avec géolocalisation, paiements intégrés et notifications push.',
          budget: 5000,
          budget_type: 'fixed',
          category: 'Développement Web',
          status: 'open',
          created_at: '2025-06-19T16:45:00Z',
          client_name: 'Antoine Moreau',
          client_rating: 4.6,
          location: 'Lyon',
          skills_required: ['React Native', 'Firebase', 'Maps API'],
          experience_level: 'expert',
          duration: '3-4 mois',
          proposals_count: 6
        },
        {
          id: '5',
          title: 'Traduction site web français vers anglais',
          description: 'Site web corporate de 30 pages à traduire du français vers l\'anglais. Domaine de l\'ingénierie.',
          budget: 800,
          budget_type: 'fixed',
          category: 'Traduction',
          status: 'open',
          created_at: '2025-06-23T11:20:00Z',
          client_name: 'Claire Dupont',
          client_rating: 4.5,
          location: 'Remote',
          skills_required: ['Traduction', 'Technique', 'Anglais natif'],
          experience_level: 'intermediate',
          duration: '2 semaines',
          proposals_count: 10
        },
        {
          id: '6',
          title: 'Stratégie marketing digital et SEA',
          description: 'Consultant marketing pour définir et mettre en œuvre une stratégie de croissance incluant Google Ads, Facebook Ads et SEO.',
          budget: 80,
          budget_type: 'hourly',
          category: 'Marketing Digital',
          status: 'open',
          created_at: '2025-06-18T13:10:00Z',
          client_name: 'Lucas Bernard',
          client_rating: 4.9,
          location: 'Marseille',
          skills_required: ['Google Ads', 'Facebook Ads', 'SEO', 'Analytics'],
          experience_level: 'expert',
          duration: '6 mois',
          proposals_count: 4
        }
      ]

      setJobs(mockJobs)
    } catch (error) {
      console.error('Erreur lors du chargement des missions:', error)
    } finally {
      setLoading(false)
    }
  }

  const filterJobs = () => {
    let filteredJobs = [...jobs]

    // Search filter
    if (searchTerm) {
      filteredJobs = filteredJobs.filter(job =>
        job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.skills_required.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    }

    // Category filter
    if (selectedCategory) {
      filteredJobs = filteredJobs.filter(job => job.category === selectedCategory)
    }

    // Experience level filter
    if (selectedExperience) {
      filteredJobs = filteredJobs.filter(job => job.experience_level === selectedExperience)
    }

    // Budget type filter
    if (selectedBudgetType) {
      filteredJobs = filteredJobs.filter(job => job.budget_type === selectedBudgetType)
    }

    // Budget range filter
    if (selectedBudgetRange) {
      filteredJobs = filteredJobs.filter(job => {
        const budget = job.budget_type === 'hourly' ? job.budget * 40 : job.budget // Estimate monthly for hourly
        switch (selectedBudgetRange) {
          case '0-500':
            return budget < 500
          case '500-1000':
            return budget >= 500 && budget <= 1000
          case '1000-2500':
            return budget >= 1000 && budget <= 2500
          case '2500-5000':
            return budget >= 2500 && budget <= 5000
          case '5000+':
            return budget > 5000
          default:
            return true
        }
      })
    }

    // Sort
    filteredJobs.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        case 'oldest':
          return new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        case 'budget_high':
          return b.budget - a.budget
        case 'budget_low':
          return a.budget - b.budget
        case 'proposals':
          return b.proposals_count - a.proposals_count
        default:
          return 0
      }
    })

    return filteredJobs
  }

  const getExperienceBadge = (level: string) => {
    const levelMap = {
      'beginner': { label: 'Débutant', color: 'bg-green-100 text-green-800' },
      'intermediate': { label: 'Intermédiaire', color: 'bg-blue-100 text-blue-800' },
      'expert': { label: 'Expert', color: 'bg-purple-100 text-purple-800' }
    }
    const levelInfo = levelMap[level as keyof typeof levelMap] || levelMap.beginner
    return <Badge className={levelInfo.color}>{levelInfo.label}</Badge>
  }

  const clearFilters = () => {
    setSearchTerm('')
    setSelectedCategory('')
    setSelectedExperience('')
    setSelectedBudgetRange('')
    setSelectedBudgetType('')
  }

  const filteredJobs = filterJobs()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Missions disponibles
          </h1>
          <p className="text-gray-600">
            Trouvez la mission parfaite parmi {jobs.length} opportunités
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border p-6 sticky top-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold">Filtres</h2>
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  Effacer
                </Button>
              </div>

              <div className="space-y-6">
                {/* Search */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Recherche</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Mots-clés, compétences..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <Separator />

                {/* Category */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Catégorie</Label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Toutes les catégories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Toutes les catégories</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Experience Level */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Niveau d'expérience</Label>
                  <Select value={selectedExperience} onValueChange={setSelectedExperience}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tous les niveaux" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tous les niveaux</SelectItem>
                      {experienceLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Budget Type */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Type de budget</Label>
                  <Select value={selectedBudgetType} onValueChange={setSelectedBudgetType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tous les types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tous les types</SelectItem>
                      <SelectItem value="fixed">Projet fixe</SelectItem>
                      <SelectItem value="hourly">Tarif horaire</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Budget Range */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Fourchette de budget</Label>
                  <Select value={selectedBudgetRange} onValueChange={setSelectedBudgetRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tous les budgets" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tous les budgets</SelectItem>
                      {budgetRanges.map((range) => (
                        <SelectItem key={range.value} value={range.value}>
                          {range.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Top Bar */}
            <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="text-sm text-gray-600">
                  {filteredJobs.length} mission{filteredJobs.length !== 1 ? 's' : ''} trouvée{filteredJobs.length !== 1 ? 's' : ''}
                </div>
                
                <div className="flex items-center space-x-4">
                  {/* Sort */}
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Plus récentes</SelectItem>
                      <SelectItem value="oldest">Plus anciennes</SelectItem>
                      <SelectItem value="budget_high">Budget décroissant</SelectItem>
                      <SelectItem value="budget_low">Budget croissant</SelectItem>
                      <SelectItem value="proposals">Plus de propositions</SelectItem>
                    </SelectContent>
                  </Select>

                  {/* View Mode */}
                  <div className="flex border rounded-lg p-1">
                    <Button
                      variant={viewMode === 'grid' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('grid')}
                    >
                      <Grid className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === 'list' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('list')}
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Jobs List */}
            <div className={`space-y-6 ${viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-6' : ''}`}>
              {filteredJobs.map((job) => (
                <Card key={job.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-xl hover:text-blue-600">
                          <Link to={`/jobs/${job.id}`}>{job.title}</Link>
                        </CardTitle>
                        <CardDescription className="mt-2">
                          {job.category} • Par {job.client_name}
                          {job.client_rating && (
                            <span className="inline-flex items-center ml-2">
                              <Star className="h-3 w-3 text-yellow-400 mr-1" />
                              {job.client_rating}
                            </span>
                          )}
                        </CardDescription>
                      </div>
                      {getExperienceBadge(job.experience_level)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {job.description}
                    </p>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {job.skills_required.slice(0, 4).map((skill) => (
                        <Badge key={skill} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {job.skills_required.length > 4 && (
                        <Badge variant="outline" className="text-xs">
                          +{job.skills_required.length - 4}
                        </Badge>
                      )}
                    </div>

                    {/* Details */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-4">
                      <div className="flex items-center">
                        <DollarSign className="h-4 w-4 mr-1" />
                        {job.budget.toLocaleString()}€{job.budget_type === 'hourly' ? '/h' : ''}
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {job.duration}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {job.location}
                      </div>
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-1" />
                        {job.proposals_count} propositions
                      </div>
                    </div>

                    {/* Footer */}
                    <div className="flex justify-between items-center">
                      <div className="flex items-center text-sm text-gray-500">
                        <Calendar className="h-4 w-4 mr-1" />
                        Publié {new Date(job.created_at).toLocaleDateString()}
                      </div>
                      <Button asChild>
                        <Link to={`/jobs/${job.id}`}>
                          Voir les détails
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Empty State */}
            {filteredJobs.length === 0 && (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <Briefcase className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      Aucune mission trouvée
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Essayez de modifier vos filtres ou votre recherche
                    </p>
                    <Button onClick={clearFilters}>
                      Effacer les filtres
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
