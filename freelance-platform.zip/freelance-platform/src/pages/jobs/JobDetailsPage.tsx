import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '../../components/ui/avatar'
import { Separator } from '../../components/ui/separator'
import { 
  MapPin, 
  Clock, 
  DollarSign, 
  Users, 
  Calendar,
  Star,
  Eye,
  Heart,
  Share2,
  Flag,
  ArrowLeft,
  CheckCircle,
  MessageSquare
} from 'lucide-react'

interface Job {
  id: string
  title: string
  description: string
  budget: number
  budget_type: 'fixed' | 'hourly'
  category: string
  status: string
  created_at: string
  client_name: string
  client_avatar?: string
  client_rating?: number
  client_projects_count?: number
  client_member_since?: string
  location?: string
  skills_required: string[]
  experience_level: 'beginner' | 'intermediate' | 'expert'
  duration?: string
  proposals_count: number
  project_details?: string
  requirements?: string[]
  deliverables?: string[]
}

export default function JobDetailsPage() {
  const { id } = useParams<{ id: string }>()
  const { userProfile } = useAuth()
  const [job, setJob] = useState<Job | null>(null)
  const [loading, setLoading] = useState(true)
  const [hasApplied, setHasApplied] = useState(false)

  useEffect(() => {
    fetchJobDetails()
  }, [id])

  const fetchJobDetails = async () => {
    try {
      setLoading(true)
      
      // Mock job data for demo
      const mockJob: Job = {
        id: id || '1',
        title: 'Développement d\'une application e-commerce',
        description: 'Nous recherchons un développeur expérimenté pour créer une plateforme e-commerce complète avec React et Node.js. Le projet inclut la gestion des produits, des commandes, des paiements et un back-office administrateur.',
        budget: 3500,
        budget_type: 'fixed',
        category: 'Développement Web',
        status: 'open',
        created_at: '2025-06-20T10:00:00Z',
        client_name: 'Marie Dubois',
        client_rating: 4.8,
        client_projects_count: 12,
        client_member_since: '2023-01-15',
        location: 'France',
        skills_required: ['React', 'Node.js', 'MongoDB', 'Stripe', 'API REST', 'JavaScript', 'CSS3', 'HTML5'],
        experience_level: 'expert',
        duration: '2-3 mois',
        proposals_count: 12,
        project_details: `Nous développons une startup dans le domaine de la mode éthique et nous avons besoin d'une plateforme e-commerce robuste et moderne.

**Fonctionnalités principales :**
- Catalogue de produits avec filtres avancés
- Panier et processus de commande
- Intégration Stripe pour les paiements
- Gestion des utilisateurs et authentification
- Back-office d'administration
- Responsive design
- SEO optimisé

**Technologies souhaitées :**
- Frontend: React.js avec TypeScript
- Backend: Node.js avec Express
- Base de données: MongoDB
- Paiements: Stripe
- Déploiement: AWS ou similaire

**Timeline :**
- Phase 1 (4 semaines) : Architecture et setup
- Phase 2 (4 semaines) : Développement frontend
- Phase 3 (3 semaines) : Backend et intégrations
- Phase 4 (1 semaine) : Tests et déploiement`,
        requirements: [
          'Minimum 5 ans d\'expérience en développement web',
          'Maîtrise de React.js et Node.js',
          'Expérience avec MongoDB et les API REST',
          'Connaissance de Stripe ou solutions de paiement similaires',
          'Portfolio avec des projets e-commerce',
          'Capacité à travailler en autonomie',
          'Communication en français fluide'
        ],
        deliverables: [
          'Code source complet documenté',
          'Application déployée en production',
          'Documentation technique',
          'Guide d\'utilisation administrateur',
          'Formation à l\'utilisation de la plateforme',
          '3 mois de support technique inclus'
        ]
      }

      setJob(mockJob)
    } catch (error) {
      console.error('Erreur lors du chargement de la mission:', error)
    } finally {
      setLoading(false)
    }
  }

  const getExperienceBadge = (level: string) => {
    const levelMap = {
      'beginner': { label: 'Débutant', color: 'bg-green-100 text-green-800' },
      'intermediate': { label: 'Intermédiaire', color: 'bg-blue-100 text-blue-800' },
      'expert': { label: 'Expert', color: 'bg-purple-100 text-purple-800' }
    }
    const levelInfo = levelMap[level as keyof typeof levelMap] || levelMap.beginner
    return <Badge className={levelInfo.color}>{levelInfo.label}</Badge>
  }

  const handleApply = () => {
    // TODO: Implement proposal submission
    setHasApplied(true)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!job) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Mission non trouvée</h2>
          <p className="text-gray-600 mb-4">Cette mission n'existe pas ou a été supprimée.</p>
          <Button asChild>
            <Link to="/jobs">Retour aux missions</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Button variant="ghost" asChild className="mb-4">
            <Link to="/jobs">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour aux missions
            </Link>
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Job Header */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="text-2xl mb-2">{job.title}</CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                      <span>{job.category}</span>
                      <span>•</span>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        Publié {new Date(job.created_at).toLocaleDateString()}
                      </div>
                      <span>•</span>
                      <div className="flex items-center">
                        <Eye className="h-4 w-4 mr-1" />
                        {job.proposals_count} propositions
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                      <div className="flex items-center text-lg font-semibold text-green-600">
                        <DollarSign className="h-5 w-5 mr-1" />
                        {job.budget.toLocaleString()}€{job.budget_type === 'hourly' ? '/h' : ''}
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        {job.duration}
                      </div>
                      <div className="flex items-center text-gray-600">
                        <MapPin className="h-4 w-4 mr-1" />
                        {job.location}
                      </div>
                      {getExperienceBadge(job.experience_level)}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Heart className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Flag className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>Description du projet</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p className="text-gray-600 whitespace-pre-line">{job.project_details}</p>
                </div>
              </CardContent>
            </Card>

            {/* Skills Required */}
            <Card>
              <CardHeader>
                <CardTitle>Compétences requises</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {job.skills_required.map((skill) => (
                    <Badge key={skill} variant="outline">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            {job.requirements && (
              <Card>
                <CardHeader>
                  <CardTitle>Exigences</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {job.requirements.map((requirement, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                        <span className="text-gray-600">{requirement}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {/* Deliverables */}
            {job.deliverables && (
              <Card>
                <CardHeader>
                  <CardTitle>Livrables attendus</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {job.deliverables.map((deliverable, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-4 w-4 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                        <span className="text-gray-600">{deliverable}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Apply Card */}
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Postuler à cette mission</CardTitle>
              </CardHeader>
              <CardContent>
                {userProfile?.role === 'freelancer' ? (
                  <div className="space-y-4">
                    {!hasApplied ? (
                      <>
                        <div className="text-center py-4">
                          <div className="text-2xl font-bold text-green-600 mb-2">
                            {job.budget.toLocaleString()}€
                          </div>
                          <p className="text-sm text-gray-600">
                            {job.budget_type === 'fixed' ? 'Prix fixe' : 'Tarif horaire'}
                          </p>
                        </div>
                        <Button className="w-full" size="lg" onClick={handleApply}>
                          Postuler maintenant
                        </Button>
                        <p className="text-xs text-gray-500 text-center">
                          Votre proposition sera envoyée au client
                        </p>
                      </>
                    ) : (
                      <div className="text-center py-4">
                        <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                        <h3 className="font-medium text-gray-900 mb-2">
                          Proposition envoyée !
                        </h3>
                        <p className="text-sm text-gray-600">
                          Le client recevra votre proposition et pourra vous contacter.
                        </p>
                      </div>
                    )}
                  </div>
                ) : userProfile?.role === 'client' ? (
                  <div className="text-center py-4">
                    <p className="text-gray-600 mb-4">
                      Vous ne pouvez pas postuler à vos propres missions.
                    </p>
                    <Button asChild className="w-full">
                      <Link to="/post-job">
                        Publier une mission
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-gray-600 mb-4">
                      Connectez-vous pour postuler à cette mission.
                    </p>
                    <Button asChild className="w-full">
                      <Link to="/login">
                        Se connecter
                      </Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Client Info */}
            <Card>
              <CardHeader>
                <CardTitle>À propos du client</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-3 mb-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={job.client_avatar} />
                    <AvatarFallback>
                      {job.client_name?.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium">{job.client_name}</h3>
                    <div className="flex items-center text-sm text-gray-500">
                      <Star className="h-3 w-3 text-yellow-400 mr-1" />
                      {job.client_rating}/5
                      <span className="mx-1">•</span>
                      <MapPin className="h-3 w-3 mr-1" />
                      {job.location}
                    </div>
                  </div>
                </div>

                <Separator className="my-4" />

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Projets publiés</span>
                    <span className="font-medium">{job.client_projects_count}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Membre depuis</span>
                    <span className="font-medium">
                      {job.client_member_since && new Date(job.client_member_since).getFullYear()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Dernière activité</span>
                    <span className="font-medium">Il y a 2 jours</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full mt-4">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Contacter le client
                </Button>
              </CardContent>
            </Card>

            {/* Job Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Statistiques de la mission</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Propositions reçues</span>
                    <span className="font-medium">{job.proposals_count}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Vues de la mission</span>
                    <span className="font-medium">47</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Freelances invités</span>
                    <span className="font-medium">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Temps moyen de réponse</span>
                    <span className="font-medium">2 heures</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
