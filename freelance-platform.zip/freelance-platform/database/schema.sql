-- Schéma de la base de données pour la plateforme freelance
-- Ce script doit être exécuté dans Supabase SQL Editor

-- Extension pour les UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Table des utilisateurs (clients, freelances, administrateurs)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('client', 'freelancer', 'admin')),
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    avatar_url TEXT,
    phone TEXT,
    location TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_verified BOOLEAN DEFAULT FALSE
);

-- Table des profils freelances
CREATE TABLE freelancer_profiles (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    title TEXT,
    overview TEXT,
    hourly_rate DECIMAL(10,2),
    availability TEXT,
    country TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des compétences
CREATE TABLE skills (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    category TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table de jonction freelance-compétences
CREATE TABLE freelancer_skills (
    freelancer_profile_id UUID REFERENCES freelancer_profiles(user_id) ON DELETE CASCADE,
    skill_id INTEGER REFERENCES skills(id) ON DELETE CASCADE,
    proficiency_level INTEGER CHECK (proficiency_level BETWEEN 1 AND 5),
    PRIMARY KEY (freelancer_profile_id, skill_id)
);

-- Table des catégories de services
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id INTEGER REFERENCES categories(id),
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table des jobs/projets
CREATE TABLE jobs (
    id SERIAL PRIMARY KEY,
    client_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    budget_type TEXT NOT NULL CHECK (budget_type IN ('fixed', 'hourly')),
    budget_amount DECIMAL(10,2),
    budget_max DECIMAL(10,2),
    duration_estimate TEXT,
    experience_level TEXT CHECK (experience_level IN ('entry', 'intermediate', 'expert')),
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled', 'draft')),
    is_private BOOLEAN DEFAULT FALSE,
    category_id INTEGER REFERENCES categories(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE
);

-- Table de jonction job-compétences
CREATE TABLE job_skills (
    job_id INTEGER REFERENCES jobs(id) ON DELETE CASCADE,
    skill_id INTEGER REFERENCES skills(id) ON DELETE CASCADE,
    is_required BOOLEAN DEFAULT TRUE,
    PRIMARY KEY (job_id, skill_id)
);

-- Table des propositions/candidatures
CREATE TABLE proposals (
    id SERIAL PRIMARY KEY,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    freelancer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    cover_letter TEXT,
    proposed_rate DECIMAL(10,2) NOT NULL,
    estimated_duration TEXT,
    status TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted', 'accepted', 'rejected', 'withdrawn')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    UNIQUE(job_id, freelancer_id)
);

-- Table des WorkRooms (espaces de travail collaboratifs)
CREATE TABLE workrooms (
    id SERIAL PRIMARY KEY,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    freelancer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'disputed', 'cancelled')),
    start_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    end_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table des milestones (étapes de projet)
CREATE TABLE milestones (
    id SERIAL PRIMARY KEY,
    workroom_id INTEGER NOT NULL REFERENCES workrooms(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    amount DECIMAL(10,2) NOT NULL,
    due_date TIMESTAMP WITH TIME ZONE,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'submitted', 'approved', 'rejected')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table des messages (communication dans les WorkRooms)
CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    workroom_id INTEGER NOT NULL REFERENCES workrooms(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    message_type TEXT DEFAULT 'text' CHECK (message_type IN ('text', 'file', 'system')),
    file_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table des fichiers partagés
CREATE TABLE shared_files (
    id SERIAL PRIMARY KEY,
    workroom_id INTEGER NOT NULL REFERENCES workrooms(id) ON DELETE CASCADE,
    uploader_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    file_url TEXT NOT NULL,
    file_size INTEGER,
    mime_type TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table des transactions financières
CREATE TABLE transactions (
    id SERIAL PRIMARY KEY,
    job_id INTEGER REFERENCES jobs(id) ON DELETE CASCADE,
    milestone_id INTEGER REFERENCES milestones(id),
    payer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount DECIMAL(10,2) NOT NULL,
    commission_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    platform_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded')),
    payment_method TEXT NOT NULL CHECK (payment_method IN ('stripe', 'paypal', 'escrow')),
    stripe_payment_intent_id TEXT,
    paypal_order_id TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Table des évaluations/avis
CREATE TABLE reviews (
    id SERIAL PRIMARY KEY,
    workroom_id INTEGER NOT NULL REFERENCES workrooms(id) ON DELETE CASCADE,
    reviewer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reviewee_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    title TEXT,
    comment TEXT,
    criteria_quality INTEGER CHECK (criteria_quality BETWEEN 1 AND 5),
    criteria_communication INTEGER CHECK (criteria_communication BETWEEN 1 AND 5),
    criteria_timeliness INTEGER CHECK (criteria_timeliness BETWEEN 1 AND 5),
    criteria_professionalism INTEGER CHECK (criteria_professionalism BETWEEN 1 AND 5),
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    UNIQUE(workroom_id, reviewer_id)
);

-- Table des litiges
CREATE TABLE disputes (
    id SERIAL PRIMARY KEY,
    workroom_id INTEGER NOT NULL REFERENCES workrooms(id) ON DELETE CASCADE,
    initiated_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reason TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_review', 'resolved', 'closed')),
    resolution TEXT,
    resolved_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    resolved_at TIMESTAMP WITH TIME ZONE
);

-- Table des notifications
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    data JSONB,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table du programme d'affiliation
CREATE TABLE affiliates (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referral_code TEXT UNIQUE NOT NULL,
    commission_rate DECIMAL(5,2) DEFAULT 10.00,
    total_earnings DECIMAL(10,2) DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'inactive')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table des commissions d'affiliation
CREATE TABLE affiliate_commissions (
    id SERIAL PRIMARY KEY,
    affiliate_id INTEGER NOT NULL REFERENCES affiliates(id) ON DELETE CASCADE,
    transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    commission_amount DECIMAL(10,2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'cancelled')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    paid_at TIMESTAMP WITH TIME ZONE
);

-- Table de suivi du temps (pour projets horaires)
CREATE TABLE time_tracking (
    id SERIAL PRIMARY KEY,
    workroom_id INTEGER NOT NULL REFERENCES workrooms(id) ON DELETE CASCADE,
    freelancer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE,
    duration_minutes INTEGER,
    description TEXT,
    is_approved BOOLEAN DEFAULT FALSE,
    approved_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Table des invitations (pour jobs privés)
CREATE TABLE job_invitations (
    id SERIAL PRIMARY KEY,
    job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    freelancer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    invited_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined', 'expired')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(job_id, freelancer_id)
);

-- Indexes pour optimiser les performances
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_jobs_client_id ON jobs(client_id);
CREATE INDEX idx_jobs_status ON jobs(status);
CREATE INDEX idx_jobs_category_id ON jobs(category_id);
CREATE INDEX idx_proposals_job_id ON proposals(job_id);
CREATE INDEX idx_proposals_freelancer_id ON proposals(freelancer_id);
CREATE INDEX idx_workrooms_job_id ON workrooms(job_id);
CREATE INDEX idx_workrooms_freelancer_id ON workrooms(freelancer_id);
CREATE INDEX idx_messages_workroom_id ON messages(workroom_id);
CREATE INDEX idx_transactions_job_id ON transactions(job_id);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);

-- Triggers pour la mise à jour automatique des timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_freelancer_profiles_updated_at BEFORE UPDATE ON freelancer_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insertion des données de base (catégories et compétences)
INSERT INTO categories (name, description) VALUES
('Développement Web', 'Création de sites web et applications web'),
('Développement Mobile', 'Applications iOS, Android et cross-platform'),
('Design Graphique', 'Logo, branding, illustrations, UI/UX'),
('Rédaction et Traduction', 'Contenu, copywriting, traduction'),
('Marketing Digital', 'SEO, publicité en ligne, réseaux sociaux'),
('Data Science', 'Analyse de données, IA, machine learning'),
('Consultation Business', 'Stratégie, finance, management'),
('Vidéo et Animation', 'Montage vidéo, animation, motion design');

INSERT INTO skills (name, category) VALUES
-- Développement Web
('React', 'Frontend'),
('Vue.js', 'Frontend'),
('Angular', 'Frontend'),
('Node.js', 'Backend'),
('Python', 'Backend'),
('PHP', 'Backend'),
('JavaScript', 'Programming'),
('TypeScript', 'Programming'),
('HTML', 'Frontend'),
('CSS', 'Frontend'),
('Tailwind CSS', 'Frontend'),
('Next.js', 'Frontend'),
('Express.js', 'Backend'),
('Django', 'Backend'),
('Laravel', 'Backend'),

-- Développement Mobile
('React Native', 'Mobile'),
('Flutter', 'Mobile'),
('iOS Development', 'Mobile'),
('Android Development', 'Mobile'),
('Swift', 'Programming'),
('Kotlin', 'Programming'),

-- Design
('Figma', 'Design'),
('Adobe Photoshop', 'Design'),
('Adobe Illustrator', 'Design'),
('Sketch', 'Design'),
('UI/UX Design', 'Design'),
('Logo Design', 'Design'),

-- Marketing
('SEO', 'Marketing'),
('Google Ads', 'Marketing'),
('Facebook Ads', 'Marketing'),
('Content Marketing', 'Marketing'),
('Email Marketing', 'Marketing'),

-- Data Science
('Machine Learning', 'Data'),
('Python Data Analysis', 'Data'),
('SQL', 'Data'),
('Tableau', 'Data'),
('Power BI', 'Data');

-- Fonction pour générer des codes de parrainage uniques
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS TEXT AS $$
DECLARE
    code TEXT;
    exists BOOLEAN := TRUE;
BEGIN
    WHILE exists LOOP
        code := upper(substring(md5(random()::text) from 1 for 8));
        SELECT COUNT(*) > 0 INTO exists FROM affiliates WHERE referral_code = code;
    END LOOP;
    RETURN code;
END;
$$ LANGUAGE plpgsql;

-- Politiques de sécurité RLS (Row Level Security)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE freelancer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE workrooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Politiques pour les utilisateurs (les utilisateurs peuvent voir et modifier leurs propres données)
CREATE POLICY "Users can view own profile" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON users FOR UPDATE USING (auth.uid() = id);

-- Politiques pour les profils freelance
CREATE POLICY "Anyone can view freelancer profiles" ON freelancer_profiles FOR SELECT USING (true);
CREATE POLICY "Freelancers can update own profile" ON freelancer_profiles FOR ALL USING (auth.uid() = user_id);

-- Politiques pour les jobs
CREATE POLICY "Anyone can view open jobs" ON jobs FOR SELECT USING (status = 'open' OR client_id = auth.uid());
CREATE POLICY "Clients can manage their jobs" ON jobs FOR ALL USING (client_id = auth.uid());

-- Politiques pour les propositions
CREATE POLICY "Users can view relevant proposals" ON proposals FOR SELECT USING (
    freelancer_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM jobs WHERE jobs.id = proposals.job_id AND jobs.client_id = auth.uid())
);
CREATE POLICY "Freelancers can create proposals" ON proposals FOR INSERT WITH CHECK (freelancer_id = auth.uid());
CREATE POLICY "Freelancers can update own proposals" ON proposals FOR UPDATE USING (freelancer_id = auth.uid());

-- Politiques pour les workrooms
CREATE POLICY "Workroom participants can access" ON workrooms FOR SELECT USING (
    freelancer_id = auth.uid() OR client_id = auth.uid()
);

-- Politiques pour les messages
CREATE POLICY "Workroom participants can view messages" ON messages FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM workrooms 
        WHERE workrooms.id = messages.workroom_id 
        AND (workrooms.freelancer_id = auth.uid() OR workrooms.client_id = auth.uid())
    )
);
CREATE POLICY "Workroom participants can send messages" ON messages FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM workrooms 
        WHERE workrooms.id = workroom_id 
        AND (workrooms.freelancer_id = auth.uid() OR workrooms.client_id = auth.uid())
    ) AND sender_id = auth.uid()
);

-- Politiques pour les notifications
CREATE POLICY "Users can view own notifications" ON notifications FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can update own notifications" ON notifications FOR UPDATE USING (user_id = auth.uid());
