import { useState, useEffect } from 'react'
import { Dashboard } from './components/Dashboard'
import { Projects } from './components/Projects'
import { Freelancers } from './components/Freelancers'
import { Sidebar } from './components/Sidebar'
import { Header } from './components/Header'
import './App.css'

type View = 'dashboard' | 'projects' | 'freelancers'

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />
      case 'projects':
        return <Projects />
      case 'freelancers':
        return <Freelancers />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar 
        currentView={currentView} 
        onViewChange={setCurrentView}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto px-6 py-8">
          {renderView()}
        </main>
      </div>
    </div>
  )
}

export default App
