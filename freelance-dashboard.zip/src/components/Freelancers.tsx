import { useState, useEffect } from 'react'
import { Search, Star, MapPin, Clock, DollarSign, CheckCircle, XCircle } from 'lucide-react'

interface Freelancer {
  id: number
  name: string
  title: string
  image: string
  rating: number
  reviewsCount: number
  hourlyRate: number
  skills: string[]
  description: string
  completedProjects: number
  location: string
  available: boolean
  specialties: string[]
}

export function Freelancers() {
  const [freelancers, setFreelancers] = useState<Freelancer[]>([])
  const [filteredFreelancers, setFilteredFreelancers] = useState<Freelancer[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [skillFilter, setSkillFilter] = useState<string>('all')
  const [availabilityFilter, setAvailabilityFilter] = useState<string>('all')
  const [sortBy, setSortBy] = useState<string>('rating')

  useEffect(() => {
    const fetchFreelancers = async () => {
      try {
        const response = await fetch('/data/freelancers.json')
        const data = await response.json()
        setFreelancers(data.freelancers)
        setFilteredFreelancers(data.freelancers)
      } catch (error) {
        console.error('Erreur lors du chargement des freelances:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchFreelancers()
  }, [])

  useEffect(() => {
    let filtered = [...freelancers]

    // Filtre par recherche
    if (searchTerm) {
      filtered = filtered.filter(freelancer =>
        freelancer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        freelancer.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        freelancer.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    }

    // Filtre par compétence
    if (skillFilter !== 'all') {
      filtered = filtered.filter(freelancer =>
        freelancer.skills.some(skill => skill.toLowerCase().includes(skillFilter.toLowerCase()))
      )
    }

    // Filtre par disponibilité
    if (availabilityFilter !== 'all') {
      filtered = filtered.filter(freelancer =>
        availabilityFilter === 'available' ? freelancer.available : !freelancer.available
      )
    }

    // Tri
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'rating':
          return b.rating - a.rating
        case 'rate':
          return b.hourlyRate - a.hourlyRate
        case 'projects':
          return b.completedProjects - a.completedProjects
        case 'name':
          return a.name.localeCompare(b.name)
        default:
          return 0
      }
    })

    setFilteredFreelancers(filtered)
  }, [freelancers, searchTerm, skillFilter, availabilityFilter, sortBy])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(amount)
  }

  const allSkills = [...new Set(freelancers.flatMap(f => f.skills))]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Freelances</h1>
          <p className="mt-2 text-gray-600">Découvrez et engagez les meilleurs talents</p>
        </div>
        <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 transition-colors">
          Inviter un Freelance
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Rechercher un freelance..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Skill Filter */}
          <select
            value={skillFilter}
            onChange={(e) => setSkillFilter(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">Toutes les compétences</option>
            {allSkills.map(skill => (
              <option key={skill} value={skill}>{skill}</option>
            ))}
          </select>

          {/* Availability Filter */}
          <select
            value={availabilityFilter}
            onChange={(e) => setAvailabilityFilter(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">Toutes disponibilités</option>
            <option value="available">Disponible</option>
            <option value="unavailable">Non disponible</option>
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="rating">Meilleure note</option>
            <option value="rate">Tarif décroissant</option>
            <option value="projects">Plus de projets</option>
            <option value="name">Nom A-Z</option>
          </select>

          {/* Results Count */}
          <div className="flex items-center justify-center">
            <span className="text-sm text-gray-600">
              {filteredFreelancers.length} freelance{filteredFreelancers.length > 1 ? 's' : ''} trouvé{filteredFreelancers.length > 1 ? 's' : ''}
            </span>
          </div>
        </div>
      </div>

      {/* Freelancers Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredFreelancers.map((freelancer) => (
          <div key={freelancer.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            {/* Profile Header */}
            <div className="flex items-start space-x-4 mb-4">
              <img
                src={freelancer.image}
                alt={freelancer.name}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">{freelancer.name}</h3>
                  {freelancer.available ? (
                    <div className="flex items-center space-x-1">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span className="text-xs text-green-600 font-medium">Disponible</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-1">
                      <XCircle className="w-4 h-4 text-red-500" />
                      <span className="text-xs text-red-600 font-medium">Occupé</span>
                    </div>
                  )}
                </div>
                <p className="text-sm text-gray-600 mb-2">{freelancer.title}</p>
                
                {/* Rating */}
                <div className="flex items-center space-x-2">
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium text-gray-900 ml-1">{freelancer.rating}</span>
                  </div>
                  <span className="text-sm text-gray-500">({freelancer.reviewsCount} avis)</span>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-center space-x-2">
                <DollarSign className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{formatCurrency(freelancer.hourlyRate)}/h</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{freelancer.completedProjects} projets</span>
              </div>
            </div>

            {/* Location */}
            <div className="flex items-center space-x-2 mb-4">
              <MapPin className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">{freelancer.location}</span>
            </div>

            {/* Description */}
            <p className="text-sm text-gray-600 mb-4 line-clamp-2">
              {freelancer.description}
            </p>

            {/* Skills */}
            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Compétences</h4>
              <div className="flex flex-wrap gap-2">
                {freelancer.skills.slice(0, 4).map((skill, index) => (
                  <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                    {skill}
                  </span>
                ))}
                {freelancer.skills.length > 4 && (
                  <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                    +{freelancer.skills.length - 4}
                  </span>
                )}
              </div>
            </div>

            {/* Specialties */}
            <div className="mb-6">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Spécialités</h4>
              <div className="flex flex-wrap gap-2">
                {freelancer.specialties.map((specialty, index) => (
                  <span key={index} className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs">
                    {specialty}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex space-x-2">
              <button className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
                Voir profil
              </button>
              <button className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:from-blue-600 hover:to-purple-700 transition-colors">
                Contacter
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredFreelancers.length === 0 && (
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucun freelance trouvé</h3>
          <p className="text-gray-600">Essayez de modifier vos critères de recherche</p>
        </div>
      )}
    </div>
  )
}
